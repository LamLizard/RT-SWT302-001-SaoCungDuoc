# Lệnh và bằng chứng thực thi — đóng pilot 23/10/2026

Thực hiện từ gốc workspace bằng Python đã có; không cài dependency. Các lệnh dưới đây là thao tác đã thực hiện, không phải đề nghị gọi model/SUT. Một agent, không commit/push hoặc gửi email.

## Môi trường lệnh

```powershell
$taskPython = '.local/RESTestBench/.venv/Scripts/python.exe'
$taskResult = '.local/pilot-preparation/pilot-reconciliation-20261023-01'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD = '1'
```

## Snapshot và integrity

`git status --short` trước sửa ghi `.gitignore` modified và file mail untracked. Không sửa hai file này. Đã đọc context, mail gốc, RQ/thiết kế, manifest/prompt/config/lịch, run/receipt/log/JUnit và golden/release, không tra web/PDF mới.

```powershell
& $taskPython -B "$taskResult/capture_snapshot.py"
```

Exit 0; 2.007 bản sao, 1.601 file run gốc, source khớp identity trước sửa. Lần copy lồng thư mục ban đầu lỗi Windows MAX_PATH; bản copy dang dở giữ ở `snapshot/`. Bản chính thức dùng `snapshot-files/` tên ngắn và `snapshot-manifest.json` ánh xạ. Có hai lần lập inventory compact trước sửa: script capture đã báo tập bảo vệ mục tiêu 651 file; một tiến trình capture inline trước đó còn chạy và xuất inventory rộng hơn gồm **28.741 file** (toàn bộ file tracked có sẵn của checkout benchmark + năm study artifact). Manifest chính thức có mtime 05:03:56 UTC, Git status chỉ có hai thay đổi sẵn của người dùng; provenance trước/sau và kiểm cuối đều đối chiếu cùng tập 28.741 file đó. Các hash nguồn runner trong bản sao vẫn khớp identity run cũ; không dùng script capture như công cụ resume hoặc thay identity. Việc inventory rộng hơn cần thiết đã phát sinh ở lần chụp đầu, không phải thay đổi benchmark hoặc sweep runtime. Script capture từ chối khi đã có manifest; không chạy lại sau sửa.

## Tái hiện và regression tập trung

```powershell
& $taskPython -B -m pytest '.local/pilot-preparation/test_quality_failure.py' -q -p no:cacheprovider --basetemp '.local/pq-red' --junitxml "$taskResult/red-quality.xml"
& $taskPython -B -m pytest '.local/pilot-preparation/test_quality_failure.py' -q -p no:cacheprovider --basetemp '.local/pq-red2' --junitxml "$taskResult/red-quality-baseline.xml"
& $taskPython -B -m pytest '.local/pilot-preparation/test_quality_failure.py' '.local/pilot-preparation/test_execution.py' -q -p no:cacheprovider --basetemp '.local/pq-green' --junitxml "$taskResult/green-quality.xml"
& $taskPython -B -m pytest '.local/pilot-preparation/test_quality_failure.py' '.local/pilot-preparation/test_execution.py' -q -p no:cacheprovider --basetemp '.local/pq-green2' --junitxml "$taskResult/green-quality-fixed.xml"
```

Lịch sử: `red-quality.*` 25 fail/1 pass, exit 1 (API classifier chưa có); `red-quality-baseline.*` 3 fail/23 pass, exit 1. Fixture đầu bị thay JWT bằng chuỗi có dấu `< >` làm XML không hợp lệ; đã sửa riêng redaction fixture thành marker XML an toàn. `green-quality.*` 3 fail/38 pass, exit 1 ở giai đoạn đó; `green-quality-fixed.*` 41 pass, exit 0. Không sửa log/JUnit/generated source của run thật. Không dùng các lần red/fixture sai làm bằng chứng kết quả pilot.

```powershell
& $taskPython -B "$taskResult/replay_legacy_regression.py"
```

Exit 1 dự kiến, **3 fail/24 deselected**, `red-legacy-final-fixture.xml` và `.log`. Script kiểm SHA256 rồi import đúng `execution_guard.py` trước sửa từ snapshot, dùng fixture cuối hợp lệ; scoring cũ trả `unresolved`, score null. Đây là bằng chứng regression fail-before chính thức, không dùng identity giả hoặc live resume.

```powershell
& $taskPython -B -m pytest '.local/pilot-preparation/test_quality_failure.py' '.local/pilot-preparation/test_execution.py' '.local/pilot-preparation/test_pilot_report.py' '.local/pilot-preparation/test_reconcile_pilot.py' -q -p no:cacheprovider --basetemp '.local/pr-green' --junitxml "$taskResult/green-focused.xml"
& $taskPython -B -m pytest '.local/pilot-preparation/test_reconcile_pilot.py' -vv -s -p no:cacheprovider --basetemp '.local/pr-debug' --junitxml "$taskResult/reconcile-tests.xml"
```

Tập trung **54 pass**, exit 0, `green-focused.log/xml`. Chạy riêng cơ chế đối soát **8 pass**, exit 0, `reconcile-tests.xml`; stdout có trong kết quả lệnh của chat. Sau đó thêm một unit test kiểm adapter `SUTRunner.evaluate` bằng receipt/fake manager (không SUT thật), thuộc bộ unit cuối.

## Unit đầy đủ và chẩn đoán sandbox

```powershell
$unitFiles = @(Get-ChildItem -LiteralPath '.local/pilot-preparation' -Filter 'test_*.py' -File | ForEach-Object { $_.FullName })
$unitFiles += (Resolve-Path -LiteralPath '.local/environment-verification/test_full_golden.py').Path
& $taskPython -B -m pytest @unitFiles -q -p no:cacheprovider --basetemp '.local/pu-close' --junitxml "$taskResult/unit-closeout.xml"
```

Lượt sandbox đầu: exit 1, **135 pass/1 fail**, không skip/error; kết quả được bảo toàn tại `unit-sandbox.log/xml` trước chạy lại. Test fail là `test_worker_posts_once_to_loopback_and_keeps_full_sanitized_body`; worker ghi ConnectionError, không nhận HTTP 503 giả lập.

```powershell
& $taskPython -B -m pytest '.local/pilot-preparation/test_live_client.py::test_worker_posts_once_to_loopback_and_keeps_full_sanitized_body' -q -p no:cacheprovider --basetemp '.local/pl-repro' --junitxml "$taskResult/loopback-repro.xml"
```

Exit 1, 1 fail; `loopback-repro.log/xml`. Probe tối thiểu GET tới `ThreadingHTTPServer(127.0.0.1, port ngẫu nhiên)` với `trust_env=False` vẫn lỗi WinError 10013 (“socket ... forbidden by its access permissions”); không có proxy env. Probe chỉ dùng mạng loopback, không SUT/provider. Một phép đọc tiến trình bằng CIM bị hệ thống từ chối; không được dùng làm bằng chứng test.

```powershell
& $taskPython -B -m pytest '.local/pilot-preparation/test_live_client.py::test_worker_posts_once_to_loopback_and_keeps_full_sanitized_body' -q -p no:cacheprovider --basetemp '.local/pl-allow' --junitxml "$taskResult/loopback-allowed.xml"
& $taskPython -B -m pytest @unitFiles -q -p no:cacheprovider --basetemp '.local/pu-final' --junitxml "$taskResult/unit-closeout.xml"
```

Hai lệnh này chạy ngoài sandbox sau khi quyền kết nối loopback được chấp nhận. Test riêng **1 pass**, exit 0 (`loopback-allowed.log/xml`). Kết quả bộ unit cuối đọc từ `unit-closeout.log/xml` và `final-checks.json`; chỉ công bố pass khi XML thực có không fail/error/skip. Không sửa worker/test transport và không gọi API thật, dùng credential giả của fixture. Không coi unit là smoke SUT nguồn mới.

## Đối soát bằng artifact, không qua constructor live

```powershell
& $taskPython -B '.local/pilot-preparation/reconcile_pilot.py' --root '.' --source '.local/pilot-preparation/pilot-run-20261023-01' --snapshot $taskResult --output $taskResult
```

Exit 0, `reconciliation.log`. `report.json` do hàm aggregate hiện có tính: 24 generation/evaluation, C 19/25 (76%), I 18/25 (72%), I−C −4 điểm phần trăm; không missing/unresolved, cleanup lịch sử hợp lệ, unknown charge rỗng. Một amendment có lý do, 23 slot đã scored không đổi. Chỉ đọc ledger có sẵn; 24 model attempt giữ nguyên.

## Xuất hồ sơ và kiểm cuối

```powershell
& $taskPython -B "$taskResult/export_closeout.py"
& $taskPython -B "$taskResult/finalize_delivery.py"
git diff --check
git status --short
```

Kết quả thực cuối và hash gói ZIP được ghi ở `final-checks.json` / `delivery-checks.json`; lệnh export/finalize chỉ chạy sau unit cuối đạt. Log export `export.log`; log kiểm cuối `delivery.log`. Không chạy golden/Docker/build sweep, không revalidate giá/model/smoke, không install, commit/push hoặc gửi mail. Các source/receipt baseline giữ nguyên; metadata JSON cũ là lịch sử, không đổi thành source validation của bản mới.
