# Bước 1 — Full golden audit và blocker

Kết luận: đã triển khai runner và xử lý đủ ma trận 106 requirement / 228 mutant. Gate xác minh toàn benchmark vẫn **BLOCKED** do một mutant NestJS không biên dịch. Chưa đủ điều kiện tuyên bố tất cả 228 mutant đã được golden runtime-validated hoặc chuyển sang pilot.

Hồ sơ review gate đã chốt ngày 23/10/2026 theo yêu cầu người dùng: báo cáo đầy đủ mutant không biên dịch, giữ nguyên benchmark/mẫu số và `step_1_complete=false`; pilot/main chưa được cho chạy. `step-1-closure.json` ghi trạng thái hồ sơ hoàn tất và gate thực thi vẫn bị chặn.

Chạy ngày 22–23/10/2026 (Asia/Saigon). Benchmark commit: `4decc1e36ea3dd41b64ce3e3ac6a85bc72df36ae`.

| Dịch vụ | Original pass | Assertion kill | Lỗi chuẩn bị | Mutant tổng | Restored pass | Lượt pytest |
|---|---:|---:|---:|---:|---:|---:|
| fastapi | 63 | 141 | 0 | 141 | 63 | 267 |
| nestjs-realworld | 29 | 64 | 1 | 65 | 29 | 122 |
| todoapp | 14 | 22 | 0 | 22 | 14 | 50 |
| **Tổng** | **106** | **227** | **1** | **228** | **106** | **439** |

## Phạm vi và cách đếm

- Đủ 334 record benchmark = 106 original + 228 mutant, cùng 106 record kiểm tra khôi phục. Không thiếu/trùng ID; 0 survived; 0 skipped.
- Thực tế có 439 lượt pytest: 106 original + 227 mutant + 106 restored original. Một mutant bị chặn trước pytest. Các failed pytest do assertion trên mutant là phát hiện hợp lệ.
- Mẫu số vẫn là 228. Không tính lỗi reset/health/compile thành kill; evaluator gốc không được gọi cho requirement có context chưa hợp lệ. Không công bố MS_phi hoàn chỉnh từ lượt audit này.
- Đây là golden audit; không phải kết quả C/I, pilot hoặc main. Các smoke/chẩn đoán trước đó được giữ riêng và không cộng vào 439 lượt của full run.

## Blocker đã kiểm chứng

Trong đủ **228 mutant**, chỉ ghi nhận **1 lỗi biên dịch**; 227 context mutant còn lại đã thực thi pytest và bị assertion phát hiện. FastAPI: 0/141 lỗi biên dịch được ghi nhận; NestJS: 1/65; TodoApp: 0/22. Đây là đối soát lượt full golden, chưa chạy thêm một sweep build-only độc lập.

### NestJS requirement 5, mutant index 0

- Khóa ghép: `nestjs-realworld/5/mutated_0`; chỉ số mutant native là **0-based**.
- Requirement: xác minh xóa article loại bỏ article khỏi hệ thống.
- File trong service: `src/article/article.service.ts`; chữ ký hàm ở dòng **204**, biểu thức return bị thay ở dòng **205**.

```typescript
// Chữ ký hàm giữ nguyên
async delete(slug: string): Promise<DeleteResult> {
    // Original:
    return await this.articleRepository.delete({ slug: slug});
    // Mutant thay dòng return trên bằng:
    // return { affected: 1 };
}
```

Image dùng thực tế: `sha256:4bcb98f5e75a9834031b2f151f926ec98295f7c24f7e7899540cdaccc5279ff2`. Đã đọc trực tiếp metadata của chính image local này sau audit: Node.js **v20.20.2**, TypeORM **0.2.45**, TypeScript **3.9.10**, ts-node **8.10.2**, nodemon **1.19.4**, NestJS core **7.6.18**. Việc đọc metadata dùng container tạm không mạng, không khởi động SUT/database và không chạy lại test.

**Nguyên nhân gốc:** `DeleteResult` của TypeORM đã cài khai báo `raw: any;` là trường bắt buộc, còn `affected?: number | null;` là tùy chọn. Object `{ affected: 1 }` thiếu `raw`, nên không đáp ứng kiểu kết quả mà hàm `Promise<DeleteResult>` yêu cầu. TypeScript chặn ngay khi nạp mã.

Định nghĩa type được trích từ `/app/node_modules/typeorm/query-builder/result/DeleteResult.d.ts` của image và lưu cạnh compiler log; SHA256 được kiểm tra trong `compiler-provenance.json`.

```text
src/article/article.service.ts(205,5): error TS2741: Property 'raw' is missing in type '{ affected: number; }' but required in type 'DeleteResult'.
```

**Chuỗi lỗi và tác động:**

1. Patch được áp dụng thành công; hash source trước/sau khác nhau (`patch.json`).
2. `nodemon` gọi `node ./index`; `index.js` đăng ký `ts-node/register` rồi nạp `src/main`.
3. ts-node báo TS2741, tiến trình ứng dụng crash trước khi phục vụ API.
4. `reset.sh` restart container rồi chờ `GET http://localhost:3000/api/tags`; sau 30 lần chưa sẵn sàng, script exit 1.
5. Runner ghi lỗi ở stage `reset_database_and_verify_health`; tổng thời gian chuẩn bị khoảng **32.188 giây**. Command có `timed_out=false`; pytest chưa được dispatch, nên không có pytest/JUnit cho context mutant này.
6. Golden của requirement 5 pass trên original và sau khôi phục. Lỗi quan sát được gắn với biểu thức return của mutant trong dependency/image đã ghi nhận.

**Xử lý trong nghiên cứu:** giữ nhãn raw `infrastructure_or_execution_error` và review category `invalid_mutant_compilation`; không tính kill, không ghi thành survived/skip, không tự loại khỏi 228 mutant. Chưa gọi evaluator cho requirement 5 do có context bị chặn; không công bố MS_phi hoàn chỉnh. Hành vi HTTP xóa article của mutant chưa được kiểm tra vì ứng dụng không khởi động.

**Giới hạn:** chưa xác nhận ý định của tác giả benchmark hoặc hành vi dưới dependency/cấu hình type-checking khác. Chưa sửa mutant, golden, evaluator, metric hay tắt type-checking. Nếu muốn sửa benchmark hoặc đổi protocol xử lý invalid mutant, cần một quyết định mới có provenance trước pilot/main.

**Bằng chứng:** `case-review.json`, `compilation-inventory.json`, và thư mục `nestjs-realworld/req_5/attempt_1/mutated_0/` chứa `container-compilation.log`, `compiler-provenance.json`, `DeleteResult.d.ts`, `patch.json`, `result.json`, `error.txt`, `0042-reset.sh.*`.

## Runner và sửa môi trường local

- Runner local: `run_full_golden.py`; unit tests: `test_full_golden.py`. 16/16 unit test đạt ở kiểm cuối, JUnit trong `unit-tests-final.xml`.
- Dùng GoldenTests, ServiceManager/Mutator và Evaluator tại commit khóa; giữ nguyên golden và công thức chấm. Lưu stdout/stderr nguyên vẹn, JUnit, exit code, thời gian, patch trước/sau và lỗi chuẩn bị riêng từng context.
- Kiểm tra reset độc lập: FastAPI một seeded user / zero item; các bảng dữ liệu NestJS rỗng; TodoApp zero user / zero todo. Snapshot SQLite gồm WAL để kiểm tra trạng thái sau reset.
- Git Bash trên Windows từng đổi `/app/.db/Todos.db` thành đường dẫn host. Runner và helper smoke local đặt `MSYS_NO_PATHCONV=1` chỉ trong tiến trình; script upstream giữ nguyên. Bằng chứng chẩn đoán ở thư mục sibling `reset-diagnosis-20261022`.
- Giữ healthcheck override TodoApp từ audit ban đầu: HEAD `/health`. Kiểm tra ổn định sau full run đạt Docker healthy, database rỗng và source/cache khôi phục.

## Provenance và trạng thái cuối

- Preflight đối soát 646 file; 11 object Git LFS được xác minh bằng SHA256 và kích thước từ pointer tại commit khóa.
- Python 3.11.9, Docker Desktop 4.96.2 / Linux Engine 29.9.2 / Compose 5.6.1. Dependency freeze và pip check đạt; image ID trước/sau không đổi. Image ID container thực ở `runtime-*-images.txt`.
- Golden copies khớp từng byte; study artifacts, golden/evaluator và original source giữ nguyên. 107 file trong ba cây source/cache working khớp original sau khôi phục.
- Không còn container thuộc ba project benchmark đang chạy. Images/volumes giữ lại. Post-run health không chạy thêm pytest.
- Không sửa các thay đổi có sẵn của người dùng; không commit/push; 0 lượt gọi model/API trả phí. Pilot/main chưa chạy; study-config execution_permitted vẫn false.

## Artifact kiểm tra

- `executions-full.json`, `restorations-full.json`: record đầy đủ; stdout/stderr và JUnit nằm trong từng service/req/attempt/context.
- `executions.csv`: 440 context, gồm một context bị chặn; `mutant-status.csv`: đủ 228 mutant và nhãn review.
- `case-review.json`, `run-accounting.json`: chẩn đoán blocker và bảng đếm giữ nguyên mẫu số.
- `compilation-inventory.json`: đối soát đủ 228 mutant, liệt kê 1 lỗi compile và 227 context đã thực thi pytest.
- `step-1-closure.json`: quyết định chốt hồ sơ, danh sách bằng chứng và trạng thái `step_1_complete=false` / pilot-main chưa được phép.
- `final-evidence-checks.json`: integrity đạt, execution issue 5/0 được giữ; full validation false.
- `final-runtime-checks.json`, `post-run-health/summary.json`: unit/pip/image/container/health checks cuối.
- `manifest-check.json`, `protected-file-hashes.json`, `local-amendments.json`, `runner-snapshot/`: provenance và bản runner dùng thực tế.
- `RUNNER-REPORT.md`, `summary.json`: kết quả tự động gốc, giữ nguyên trạng thái step_1_complete=false.
