"""Disclosed offline amendment of saved evidence; no model or SUT execution."""
import argparse
from collections import Counter
import copy
from datetime import datetime, timezone
import json
from pathlib import Path

from execution_guard import review_original_failure, score_requirement
from pilot_core import BudgetLedger, GuardError, prepare, save_json, sha256
from pilot_report import write_report


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


class ReadOnlyLedger(BudgetLedger):
    def __init__(self, path):
        if not Path(path).is_file():
            raise GuardError('Existing ledger required; never initialize a reconciliation ledger')
        super().__init__(path)

    def _save(self):
        raise GuardError('Offline ledger is read-only')


class SavedPilot:
    """Only the read interface consumed by write_report; no live-run constructor."""
    def __init__(self, root, output, slots, ledger_path):
        self.root, self.output, self.slots = Path(root), Path(output), slots
        self.ledger = ReadOnlyLedger(ledger_path)

    def slot_directory(self, slot):
        return self.output / 'slots' / f'{int(slot["sequence"]):02d}-{slot["arm"]}'

    def generation_records(self):
        return [read(self.slot_directory(s) / 'generation.json') for s in self.slots
                if (self.slot_directory(s) / 'generation.json').is_file()]


def verify_integrity(root, source, snapshot):
    """Check full source-run membership and bytes, protected files, snapshot copies."""
    root, source, snapshot = Path(root).resolve(), Path(source).resolve(), Path(snapshot).resolve()
    manifest = read(snapshot / 'snapshot-manifest.json')
    if Path(manifest['root']).resolve() != root or Path(manifest['source_run']).resolve() != source:
        raise GuardError('Snapshot is bound to a different root/run')
    errors = []
    actual_paths = {p.relative_to(root).as_posix() for p in source.rglob('*') if p.is_file()}
    if actual_paths != manifest['original_run_sha256'].keys():
        errors.append('Original run membership changed')
    for label in ['original_run_sha256', 'protected_sha256']:
        for relative, digest in manifest[label].items():
            path = root / relative
            if not path.is_file() or sha256(path) != digest:
                errors.append(label + ': ' + relative)
    for relative, entry in manifest['entries'].items():
        path = (snapshot / entry['snapshot_relative']).resolve()
        if not path.is_relative_to(snapshot) or not path.is_file() or sha256(path) != entry['sha256']:
            errors.append('Snapshot copy changed: ' + relative)
    identity = read(source / 'run.json')['identity']
    if identity != manifest['source_identity'] or not manifest['source_identity_matches_before_edit']:
        errors.append('Original identity differs from pre-edit snapshot')
    for name, digest in identity['runtime_source_sha256'].items():
        key = '.local/pilot-preparation/' + name
        if manifest['entries'].get(key, {}).get('sha256') != digest:
            errors.append('Original source identity mismatch: ' + name)
    ledger = Path(identity['ledger_path'])
    entry = manifest['entries'].get(ledger.relative_to(root).as_posix(), {})
    if not ledger.is_file() or sha256(ledger) != entry.get('sha256'):
        errors.append('Ledger changed')
    for rel, key in [('vendor/flash-1017/provenance.json', 'tokenizer_provenance_sha256'),
                     ('public-evidence/pricing.json', 'pricing_receipt_sha256')]:
        if sha256(root / '.local/pilot-preparation' / rel) != identity[key]:
            errors.append('Identity evidence changed: ' + rel)
    if errors:
        raise GuardError('; '.join(errors))
    return {'verified': True, 'original_run_files': len(actual_paths),
            'protected_files': len(manifest['protected_sha256']), 'snapshot_files': len(manifest['entries']),
            'original_run_unchanged': True, 'ledger_unchanged': True, 'protected_files_unchanged': True,
            'old_runtime_identity_verified_from_snapshot': True}


def reconcile(root, source, output, snapshot):
    root, source, output, snapshot = (Path(p).resolve() for p in [root, source, output, snapshot])
    if output == source or output.is_relative_to(source) or source.is_relative_to(output):
        raise GuardError('Derived output must be separate from the original run')
    if any((output / name).exists() for name in ['report.json', 'provenance.json', 'amendments.json']):
        raise GuardError('Derived result already exists; choose a new directory')
    before = verify_integrity(root, source, snapshot)
    identity = read(source / 'run.json')['identity']
    ledger_path = Path(identity['ledger_path'])
    batch = root / '.local/pilot-preparation/pilot-inputs-20261023-101706'
    if sha256(batch / 'prepared-pilot.json') != identity['batch_sha256']:
        raise GuardError('Batch identity mismatch')
    prepared = read(batch / 'prepared-pilot.json')
    expected = prepare(root, root / '.local/RESTestBench')
    if prepared['slots'] != expected['slots'] or prepared['config_sha256'] != identity['study_config_sha256']:
        raise GuardError('Prepared panel/config differs from the locked inputs')
    slots = prepared['slots']
    if len({s['slot_id'] for s in slots}) != len(slots):
        raise GuardError('Duplicate scheduled slot')
    run = SavedPilot(root, source, slots, ledger_path)
    amendments, decisions, unchanged, issues = {}, [], [], []
    for slot in slots:
        directory = run.slot_directory(slot)
        path = directory / 'evaluation/evaluation.json'
        generation_path = directory / 'generation.json'
        if not path.is_file() or not generation_path.is_file():
            issues.append(slot['slot_id'] + ': missing generation/evaluation')
            continue
        evaluation, generation = read(path), read(generation_path)
        for value in [evaluation, generation]:
            if any(str(value.get(k)) != str(slot[k]) for k in ['slot_id', 'service', 'requirement_id', 'arm']):
                raise GuardError('Artifact identity mismatch: ' + slot['slot_id'])
        if evaluation['mutant_denominator'] != int(slot['num_mutants']):
            raise GuardError('Mutant denominator mismatch: ' + slot['slot_id'])
        if evaluation.get('score') is not None:
            check = score_requirement(evaluation['records'], root / '.local/RESTestBench',
                                      requirement_id=int(slot['requirement_id']), num_mutants=int(slot['num_mutants']))
            if check['score'] != evaluation['score']:
                raise GuardError('Existing scored evidence disagrees with evaluator: ' + slot['slot_id'])
            unchanged.append(slot['slot_id'])
            continue
        amended = copy.deepcopy(evaluation)
        records = amended.get('records', [])
        counts = Counter(r['context'] for r in records)
        if generation.get('status') == 'ready' and counts == {'valid': 1} and 'restoration_error' not in amended:
            record = records[0]
            evidence = Path(record.get('evidence', '')).resolve()
            code = Path(generation['code_path']).resolve()
            if not evidence.is_relative_to(directory.resolve()) or not code.is_relative_to(directory.resolve()):
                raise GuardError('Evidence path escapes its slot')
            amended['records'][0] = review_original_failure(
                record, generated_test=code, execution_directory=evidence / 'pytest',
                preparation_directory=evidence / 'preparation', restoration=amended.get('restoration', {}),
                service=slot['service'])
            if amended['records'][0]['classification'] == 'original_quality_failure':
                amended.update(score_requirement(amended['records'], root / '.local/RESTestBench',
                               requirement_id=int(slot['requirement_id']), num_mutants=int(slot['num_mutants'])))
        if amended != evaluation and amended.get('score') is not None:
            decision = {'slot_id': slot['slot_id'], 'historical_evaluation_sha256': sha256(path),
                        'historical_classification': evaluation['records'][0]['classification'],
                        'new_classification': amended['records'][0]['classification'],
                        'reason': 'Apply pre-existing section 5 original-fail rule to verified test-quality runtime failure',
                        'mutants_executed_for_amendment': 0, 'generated_code_changed': False}
            amended['amendment'] = decision
            amendments[slot['slot_id']] = amended
            decisions.append(decision)
        else:
            issues.append(slot['slot_id'] + ': insufficient evidence; remains unresolved')
    output.mkdir(parents=True, exist_ok=True)
    report = write_report(run, output=output, amendments=amendments)
    save_json(output / 'amendments.json', {'decisions': decisions, 'evaluations': amendments, 'issues': issues})
    for slot_id, evaluation in amendments.items():
        save_json(output / 'amended-evaluations' / (slot_id.replace('/', '_') + '.json'), evaluation)
    after = verify_integrity(root, source, snapshot)
    runtime = {p.name: sha256(p) for p in Path(__file__).parent.glob('*.py') if not p.name.startswith('test_')}
    changes = {n: {'before': identity['runtime_source_sha256'].get(n), 'after': h}
               for n, h in runtime.items() if identity['runtime_source_sha256'].get(n) != h}
    provenance = {'created_at_utc': datetime.now(timezone.utc).isoformat(), 'operation': 'offline_postprocessing_amendment',
                  'new_pilot_or_model_run': False, 'source_run': str(source), 'derived_output': str(output),
                  'snapshot_manifest': str(snapshot / 'snapshot-manifest.json'),
                  'snapshot_manifest_sha256': sha256(snapshot / 'snapshot-manifest.json'),
                  'old_runtime_source_sha256': identity['runtime_source_sha256'], 'processing_source_sha256': runtime,
                  'source_changes': changes, 'amended_slots': [d['slot_id'] for d in decisions],
                  'unchanged_scored_slot_ids': sorted(unchanged), 'issues': issues,
                  'basis': 'team-synthesis/experiment-design.md section 5, rule 1; pinned Evaluator.evaluate_test original validity gate',
                  'integrity_before': before, 'integrity_after': after, 'model_attempts_preserved': report['model_attempts'],
                  'live_constructor_used': False, 'generated_tests_executed': 0, 'paid_api_calls': 0, 'sut_started': False,
                  'ledger_sha256': sha256(ledger_path),
                  'historical_cleanup_verified': report['sut_cleanup_verified'],
                  'new_runtime_smoke_verified': False, 'new_runtime_live_preflight_verified': False,
                  'future_live_run_requires_new_source_bound_preflight_and_smoke': True,
                  'main_executed': False, 'main_freeze_approved': False,
                  'output_sha256': {n: sha256(output / n) for n in ['report.json', 'REPORT.md', 'slots.csv', 'executions.csv', 'amendments.json']}}
    save_json(output / 'provenance.json', provenance)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--snapshot', required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(reconcile(args.root, args.source, args.output, args.snapshot), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
