import requests
import uuid

BASE_URL = "http://localhost:3000/api"


def _register_user():
    username = f"testuser_{uuid.uuid4().hex[:8]}"
    email = f"{username}@example.com"
    password = "password123"
    resp = requests.post(
        f"{BASE_URL}/users",
        json={"user": {"username": username, "email": email, "password": password}},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["user"]["token"], username


def _create_article(token):
    resp = requests.post(
        f"{BASE_URL}/articles",
        headers={"Authorization": f"Token {token}"},
        json={
            "article": {
                "title": f"Test Article {uuid.uuid4().hex[:8]}",
                "description": "Test description",
                "body": "Test body",
                "tagList": ["test"],
            }
        },
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["article"]["slug"]


def _create_comment(token, slug, body):
    resp = requests.post(
        f"{BASE_URL}/articles/{slug}/comments",
        headers={"Authorization": f"Token {token}"},
        json={"comment": {"body": body}},
    )
    assert resp.status_code in (200, 201), resp.text
    return resp.json()["comment"]


def test_delete_comment_removes_from_article_comments_list():
    token, _ = _register_user()
    slug = _create_article(token)

    comment_body = f"Comment to delete {uuid.uuid4().hex[:8]}"
    comment = _create_comment(token, slug, comment_body)
    comment_id = comment["id"]
    assert isinstance(comment_id, int)
    assert comment["body"] == comment_body

    # Verify comment is present in the article's comments list
    list_resp = requests.get(f"{BASE_URL}/articles/{slug}/comments")
    assert list_resp.status_code == 200, list_resp.text
    comments_before = list_resp.json()["comments"]
    assert isinstance(comments_before, list)
    ids_before = [c["id"] for c in comments_before]
    assert comment_id in ids_before

    # Delete the comment
    del_resp = requests.delete(
        f"{BASE_URL}/articles/{slug}/comments/{comment_id}",
        headers={"Authorization": f"Token {token}"},
    )
    assert del_resp.status_code == 200, del_resp.text

    # Verify comment is no longer in the article's comments list
    list_resp_after = requests.get(f"{BASE_URL}/articles/{slug}/comments")
    assert list_resp_after.status_code == 200, list_resp_after.text
    comments_after = list_resp_after.json()["comments"]
    assert isinstance(comments_after, list)
    ids_after = [c["id"] for c in comments_after]
    assert comment_id not in ids_after
    assert len(ids_after) == len(ids_before) - 1