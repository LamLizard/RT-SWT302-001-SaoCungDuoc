"""Replay saved evidence; never execute the generated test or start a SUT."""
import copy
import json
from pathlib import Path
import shutil

import pytest

ROOT = Path(__file__).resolve().parents[2]
FIXTURE = Path(__file__).parent / 'fixtures/original-json'


@pytest.fixture
def evidence(tmp_path):
    directory = tmp_path / 'e'
    shutil.copytree(FIXTURE, directory)
    evaluation = json.loads((directory / 'evaluation.json').read_text())
    return directory, evaluation


def review(directory, evaluation):
    import execution_guard
    review_original_failure = getattr(execution_guard, 'review_original_failure',
                                      lambda record, **kwargs: copy.deepcopy(record))
    return review_original_failure(
        evaluation['records'][0], generated_test=directory / 'test.py',
        execution_directory=directory, preparation_directory=directory / 'preparation',
        restoration=evaluation['restoration'], service=evaluation['service'])


def score(record, num_mutants=2):
    from execution_guard import score_requirement
    return score_requirement([record], ROOT / '.local/RESTestBench', requirement_id=8,
                             num_mutants=num_mutants)


def test_retained_original_keyerror_scores_zero(evidence):
    directory, evaluation = evidence
    record = review(directory, evaluation)
    assert record['classification'] == 'original_quality_failure'
    assert record['quality_review']['verified'] is True
    assert record['quality_review']['exception'] == 'KeyError'
    assert record['quality_review']['source_line'] == 33
    assert record['historical_classification'] == 'unclassified_failure'
    assert evaluation['records'][0]['classification'] == 'unclassified_failure'
    result = score(record)
    assert result['score']['score'] == 0
    assert result['score']['passes_on_valid'] is False
    assert result['score']['mutants_killed'] == []
    assert result['mutant_denominator'] == 2
    assert result['not_run_original_failed'] == ['mutated_0', 'mutated_1']


@pytest.mark.parametrize('arm', ['C', 'I'])
def test_rule_is_independent_of_arm_and_requirement(evidence, arm):
    directory, evaluation = evidence
    evaluation.update(arm=arm, requirement_id=999, slot_id='other/' + arm)
    assert review(directory, evaluation)['classification'] == 'original_quality_failure'


def test_similar_mutant_exception_never_becomes_kill(evidence):
    directory, evaluation = evidence
    evaluation['records'][0]['context'] = 'mutated_0'
    record = review(directory, evaluation)
    assert record['classification'] == 'unclassified_failure'
    assert record['counted_as_kill'] is False
    assert score(record)['status'] == 'unresolved'


@pytest.mark.parametrize('change', [
    'timeout', 'cap', 'instrumentation', 'missing_instrumentation', 'missing_junit',
    'missing_stdout', 'missing_reset', 'bad_reset', 'reset_rows', 'unhealthy',
    'not_restored', 'unfinished', 'network', 'source_mismatch', 'no_location',
    'duplicate_test', 'unverified_assertions', 'non_response_keyerror',
])
def test_inadequate_or_conflicting_evidence_stays_unresolved(evidence, change):
    directory, evaluation = evidence
    record = evaluation['records'][0]
    if change == 'timeout': record['timed_out'] = True
    elif change in {'cap', 'instrumentation', 'unverified_assertions'}:
        key = {'cap': 'limit_exceeded', 'instrumentation': 'instrumentation_error',
               'unverified_assertions': 'assertion_count_verified'}[change]
        record['instrumentation'][key] = change != 'unverified_assertions'
        (directory / 'instrumentation.json').write_text(json.dumps(record['instrumentation']))
    elif change.startswith('missing_'):
        filename = {'missing_junit': 'pytest.xml', 'missing_stdout': 'stdout.log',
                    'missing_instrumentation': 'instrumentation.json'}
        if change == 'missing_reset': shutil.rmtree(directory / 'preparation')
        else: (directory / filename[change]).unlink()
    elif change in {'bad_reset', 'reset_rows'}:
        path = next((directory / 'preparation').glob('*reset-postcondition.command.json'))
        data = json.loads(path.read_text())
        data.update(return_code=1) if change == 'bad_reset' else data.update(stdout='1\t0\t0\t0\t0\t0\n')
        path.write_text(json.dumps(data))
    elif change == 'unhealthy': evaluation['restoration']['healthy'] = False
    elif change == 'not_restored': evaluation['restoration']['restored'] = False
    elif change == 'unfinished': record['stage'] = 'reset_database_health'
    elif change == 'network':
        path = directory / 'pytest.xml'
        path.write_text(path.read_text().replace("KeyError: 'article'", 'ConnectionError: offline'))
    elif change == 'source_mismatch': (directory / 'test.py').write_text('def test_a(): pass')
    elif change == 'no_location':
        path = directory / 'pytest.xml'
        path.write_text(path.read_text().replace('test.py:33: KeyError', 'unknown: KeyError'))
    elif change == 'duplicate_test':
        path = directory / 'pytest.xml'
        path.write_text(path.read_text().replace('</testsuite>', '<testcase name="extra"/></testsuite>'))
    elif change == 'non_response_keyerror':
        # An arbitrary dict KeyError must not be treated as an evidenced response mismatch.
        for name in ['test.py', 'pytest.xml', 'stdout.log']:
            path = directory / name
            path.write_text(path.read_text().replace('resp.json()', 'dict()'))
    assert review(directory, evaluation)['classification'] != 'original_quality_failure'
    assert score(review(directory, evaluation))['status'] == 'unresolved'


def test_unverified_quality_label_cannot_bypass_scoring_gate():
    assert score({'context': 'valid', 'classification': 'original_quality_failure'})['status'] == 'unresolved'


@pytest.mark.parametrize('kind', ['budget_exceeded', 'instrumentation_error'])
def test_cap_and_instrumentation_override_quality_label(evidence, kind):
    directory, evaluation = evidence
    record = review(directory, evaluation)
    record['instrumentation']['limit_exceeded' if kind == 'budget_exceeded' else 'instrumentation_error'] = True
    assert score(record)['status'] == 'unresolved'


def test_quality_failure_preserves_duplicate_and_unknown_context_gates(evidence):
    from execution_guard import score_requirement
    directory, evaluation = evidence
    record = review(directory, evaluation)
    for records in [[record, copy.deepcopy(record)],
                    [record, {'context': 'unknown', 'classification': 'survived'}],
                    [dict(record, context='mutated_0')]]:
        assert score_requirement(records, ROOT / '.local/RESTestBench', requirement_id=8,
                                 num_mutants=2)['status'] == 'unresolved'


def test_sut_evaluation_uses_same_review_after_verified_restore(tmp_path):
    from types import SimpleNamespace
    from sut_runner import SUTRunner
    directory = tmp_path / 'saved'
    shutil.copytree(FIXTURE, directory / 'pytest')
    shutil.copytree(FIXTURE / 'preparation', directory / 'preparation')
    evaluation = json.loads((FIXTURE / 'evaluation.json').read_text())
    valid = evaluation['records'][0]
    valid['evidence'] = str(directory)
    runner = SUTRunner(ROOT, 'nestjs-realworld', tmp_path / 'service', manager=SimpleNamespace())
    runner.run_context = lambda *args, **kwargs: copy.deepcopy(valid)
    runner.restore = lambda *args: copy.deepcopy(evaluation['restoration'])
    # This exercises the SUTRunner adapter entirely with retained receipts.
    result = runner.evaluate({'slot_id': 'offline/I', 'arm': 'I', 'status': 'ready',
                              'code_path': str(directory / 'pytest/test.py')},
                             {'requirement_id': 8, 'path': 'data/requirements/nestjs-realworld/requirement_8.json',
                              'num_mutants': 2, 'mutant_indices': [0, 1]}, tmp_path / 'evaluation')
    assert result['records'][0]['classification'] == 'original_quality_failure'
    assert result['score']['score'] == 0
    assert result['score']['passes_on_valid'] is False
