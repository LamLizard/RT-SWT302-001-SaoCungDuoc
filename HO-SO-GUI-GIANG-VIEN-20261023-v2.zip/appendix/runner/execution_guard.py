"""Run synthetic/offline pytest contexts and classify cap failures before evaluator input."""
from functools import lru_cache
from collections import Counter
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import re
import xml.etree.ElementTree as ET

from pilot_core import GuardError, save_json


@lru_cache(maxsize=1)
def audit_runner():
    path = Path(__file__).resolve().parents[1] / "environment-verification/run_full_golden.py"
    spec = importlib.util.spec_from_file_location("local_golden_audit", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_test(source, output, *, context="valid", request_cap=64, elapsed_cap=60, allowed_origin=None):
    if type(request_cap) is not int or not 0 < request_cap <= 64 or not 0 < elapsed_cap <= 60:
        raise GuardError("Execution budget outside the common approved caps")
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    if (output / "test.py").exists():
        raise GuardError("Execution evidence already exists")
    (output / "test.py").write_text(source, encoding="utf-8")
    env = {key: value for key, value in os.environ.items()
           if key.upper() in {"PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "PATHEXT"}}
    env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8",
               PYTHONPATH=str(Path(__file__).parent), PILOT_REQUEST_CAP=str(request_cap),
               PILOT_TEST_PATH=str(output / 'test.py'),
               PILOT_ELAPSED_CAP=str(elapsed_cap), PILOT_INSTRUMENTATION_PATH=str(output / "instrumentation.json"))
    if allowed_origin:
        env['PILOT_SUT_ORIGIN'] = allowed_origin
    argv = [sys.executable, "-m", "pytest", str(output / "test.py"), "-q", "-p", "no:cacheprovider",
            "-p", "budget_plugin", "-o", "enable_assertion_pass_hook=true",
            "--confcutdir", str(output), "--junitxml", str(output / "pytest.xml")]
    started = time.monotonic()
    timed_out = False
    with (output / "stdout.log").open("wb") as stdout, (output / "stderr.log").open("wb") as stderr:
        process = subprocess.Popen(argv, cwd=output, env=env, stdout=stdout, stderr=stderr)
        try:
            process.wait(timeout=elapsed_cap)
        except subprocess.TimeoutExpired:
            timed_out = True
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if process.poll() is None:
                process.kill()
            process.wait()
    path = output / "instrumentation.json"
    try:
        instrumentation = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        instrumentation = None
    if timed_out or (instrumentation and instrumentation["limit_exceeded"]):
        classification = "budget_exceeded"
    elif not instrumentation or instrumentation["instrumentation_error"]:
        classification = "instrumentation_error"
    elif instrumentation["invalid_test_count"]:
        classification = "invalid_test_count"
    else:
        classification = audit_runner().classify_execution(context, process.returncode, output / "pytest.xml")
    result = {"classification": classification, "context": context,
              "counted_as_kill": False,
              "eligible_mutant_assertion_failure": classification == "killed_by_assertion",
              "return_code": process.returncode,
              "timed_out": timed_out, "elapsed_seconds": time.monotonic() - started,
              "instrumentation": instrumentation, "argv": argv,
              "scope": "isolated pytest with requests instrumentation; SUT reset/patch evidence is stored by SUTRunner"}
    save_json(output / "result.json", result)
    return result


def verified_preparation(directory, service):
    """Read existing reset/health receipts; never issue a command or network request."""
    directory = Path(directory)
    resets = list(directory.glob('*-reset.sh.command.json'))
    if len(resets) != 1:
        return False
    commands = list(directory.glob('*.command.json'))
    for path in commands:
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('return_code') != 0 or data.get('timed_out') is not False:
            return False
        stem = str(path)[:-len('.command.json')]
        if Path(stem + '.stdout.log').read_text(encoding='utf-8') != data.get('stdout'):
            return False
    # A successful pinned reset script waits for service health. Independently
    # verified DB postconditions prevent a suppressed reset error from passing.
    if service == 'todoapp':
        states = list(directory.glob('reset-postcondition.json'))
        return len(states) == 1 and json.loads(states[0].read_text()) == {'AspNetUsers': 0, 'Todos': 0}
    states = list(directory.glob('*-reset-postcondition.command.json'))
    if len(states) != 1:
        return False
    data = json.loads(states[0].read_text(encoding='utf-8'))
    expected = {'fastapi': '1|0', 'nestjs-realworld': '0\t0\t0\t0\t0\t0'}
    return service in expected and data.get('stdout', '').strip() == expected[service]


def response_lookup_line(source, line):
    """Recognize a JSON lookup following a successful requests response assertion.

    Deliberately narrow: arbitrary dict KeyErrors, other exceptions, or unclear
    data flow stay unresolved. Neither an arm nor a response field is special.
    """
    tree = ast.parse(source)
    for function in ast.walk(tree):
        if not isinstance(function, ast.FunctionDef):
            continue
        lookups = [node for node in ast.walk(function) if isinstance(node, ast.Subscript)
                   and node.lineno == line]
        for lookup in lookups:
            value = lookup.value
            while isinstance(value, ast.Subscript):
                value = value.value
            if not (isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute)
                    and value.func.attr == 'json' and isinstance(value.func.value, ast.Name)):
                continue
            response = value.func.value.id
            assignments = [n for n in function.body if isinstance(n, ast.Assign)
                           and n.lineno < line and any(isinstance(t, ast.Name) and t.id == response for t in n.targets)]
            if not assignments:
                continue
            assignment = assignments[-1]
            call = assignment.value
            if not (isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                    and isinstance(call.func.value, ast.Name) and call.func.value.id == 'requests'
                    and call.func.attr in {'get', 'post', 'put', 'patch', 'delete', 'head', 'options'}):
                continue
            for check in function.body:
                if not isinstance(check, ast.Assert) or not assignment.lineno < check.lineno < line:
                    continue
                compare = check.test
                if (isinstance(compare, ast.Compare) and len(compare.ops) == 1
                        and isinstance(compare.ops[0], ast.Eq)
                        and isinstance(compare.left, ast.Attribute) and compare.left.attr == 'status_code'
                        and isinstance(compare.left.value, ast.Name) and compare.left.value.id == response
                        and isinstance(compare.comparators[0], ast.Constant)
                        and type(compare.comparators[0].value) is int
                        and 200 <= compare.comparators[0].value < 300):
                    return True
    return False


def review_original_failure(record, *, generated_test, execution_directory,
                            preparation_directory, restoration, service):
    """Amend a retained record only when independent saved evidence is sufficient."""
    amended = copy.deepcopy(record)
    metrics = record.get('instrumentation') or {}
    if record.get('timed_out') or metrics.get('limit_exceeded'):
        amended['classification'] = 'budget_exceeded'
        return amended
    if metrics.get('instrumentation_error'):
        amended['classification'] = 'instrumentation_error'
        return amended
    if (record.get('context') != 'valid' or record.get('classification') != 'unclassified_failure'
            or record.get('stage') != 'completed' or record.get('return_code') != 1
            or record.get('timed_out') is not False):
        return amended
    try:
        execution = Path(execution_directory)
        source = Path(generated_test).read_text(encoding='utf-8')
        if source != (execution / 'test.py').read_text(encoding='utf-8'):
            return amended
        if metrics != json.loads((execution / 'instrumentation.json').read_text(encoding='utf-8')):
            return amended
        if (any(metrics.get(k) is not False for k in ['limit_exceeded', 'instrumentation_error', 'invalid_test_count'])
                or metrics.get('collected_tests') != 1 or metrics.get('assertion_count_verified') is not True
                or metrics.get('http_requests', 0) < 1 or metrics.get('assertions_passed', 0) < 1
                or metrics.get('assertions_failed') != 0
                or metrics.get('assertion_count') != metrics.get('assertions_passed')):
            return amended
        if (any(restoration.get(k) is not True for k in ['restored', 'reset_verified', 'healthy'])
                or restoration.get('checked_files', 0) <= 0 or restoration.get('source_mismatches')
                or not verified_preparation(preparation_directory, service)):
            return amended
        junit = execution / 'pytest.xml'
        if audit_runner().classify_execution('valid', 1, junit) != 'unclassified_failure':
            return amended
        cases = ET.parse(junit).getroot().findall('.//testcase')
        if len(cases) != 1 or cases[0].find('error') is not None or cases[0].find('skipped') is not None:
            return amended
        failures = cases[0].findall('failure')
        if len(failures) != 1 or not failures[0].get('message', '').startswith('KeyError:'):
            return amended
        trace = failures[0].text or ''
        stdout = (execution / 'stdout.log').read_text(encoding='utf-8')
        locations = re.findall(r'(?m)^test\.py:(\d+): KeyError\s*$', trace)
        if len(locations) != 1:
            return amended
        line = int(locations[0])
        statement = source.splitlines()[line - 1].strip()
        tests = [n.name for n in ast.walk(ast.parse(source)) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
        if (tests != [cases[0].get('name')] or not response_lookup_line(source, line)
                or statement not in trace or statement not in stdout
                or f'test.py:{line}: KeyError' not in stdout
                or not re.search(r'(?m)^E\s+KeyError:', trace)
                or not re.search(r'(?m)^E\s+KeyError:', stdout)):
            return amended
        evidence_paths = [Path(generated_test), junit, execution / 'stdout.log', execution / 'instrumentation.json']
        amended.update(classification='original_quality_failure', historical_classification=record['classification'],
                       counted_as_kill=False, eligible_mutant_assertion_failure=False,
                       quality_review={'verified': True, 'exception': 'KeyError', 'source_line': line,
                           'rule': 'original response JSON lookup after asserted 2xx; saved reset/health/restoration and instrumentation verified',
                           'basis': 'experiment-design.md section 5 original-fail rule; runtime error retained, not renamed assertion',
                           'evidence_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in evidence_paths}})
    except (OSError, ValueError, KeyError, IndexError, TypeError, SyntaxError, ET.ParseError):
        return amended
    return amended


def score_requirement(records, benchmark, *, requirement_id, num_mutants):
    """Feed only resolved contexts to the pinned evaluator; never score missing evidence."""
    expected = {"valid"} | {f"mutated_{i}" for i in range(num_mutants)}
    counts = Counter(r["context"] for r in records)
    unresolved = {"status": "unresolved", "score": None, "mutant_denominator": num_mutants}
    if any(count != 1 for count in counts.values()) or counts.keys() - expected or "valid" not in counts:
        return unresolved
    if any(r.get('timed_out') or any((r.get('instrumentation') or {}).get(k)
           for k in ['limit_exceeded', 'instrumentation_error', 'invalid_test_count']) for r in records):
        return unresolved
    allowed = {"valid": {"valid_pass", "original_assertion_failure", "original_quality_failure"}}
    allowed.update({context: {"survived", "killed_by_assertion"} for context in expected - {"valid"}})
    if any(r["classification"] not in allowed[r["context"]] for r in records):
        return unresolved
    valid = next(r for r in records if r['context'] == 'valid')
    if valid['classification'] == 'original_quality_failure' and valid.get('quality_review', {}).get('verified') is not True:
        return unresolved
    original_failed = valid['classification'] in {'original_assertion_failure', 'original_quality_failure'}
    if not original_failed and counts.keys() != expected:
        return unresolved
    # Import classes only; no benchmark service manager or API client is instantiated.
    sys.path.insert(0, str(Path(benchmark).resolve()))
    try:
        import src
        if not Path(src.__file__).resolve().is_relative_to(Path(benchmark).resolve()):
            raise GuardError("Unexpected benchmark module import")
        from src.evaluator import Evaluator
        from src.executor import ExecutionResult
        from src.generator import GenerationMode
    finally:
        sys.path.pop(0)
    executions = [ExecutionResult(Path("synthetic_or_generated_test.py"), requirement_id, GenerationMode.VALID,
                                 None, r["context"], None,
                                 r["classification"] in {"valid_pass", "survived"}, "", 0, 0) for r in records]
    score = Evaluator().evaluate_test(executions, num_mutants)
    return {"status": "scored", "score": score.to_dict(), "mutant_denominator": num_mutants,
            "not_run_original_failed": sorted(expected - counts.keys()) if original_failed else []}
