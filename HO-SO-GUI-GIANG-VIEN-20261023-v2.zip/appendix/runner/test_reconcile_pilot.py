"""Real retained-artifact replay, without executing any generated test."""
import csv
import json
from pathlib import Path
import socket

import pytest

from pilot_core import GuardError, sha256

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
SOURCE = HERE / 'pilot-run-20261023-01'
SNAPSHOT = HERE / 'pilot-reconciliation-20261023-01'


def forbidden(*args, **kwargs):
    raise AssertionError('Live execution is forbidden during offline reconciliation')


def test_offline_replay_preserves_evidence_and_23_scores(tmp_path, monkeypatch):
    import execution_guard
    import pilot_orchestrator
    import sut_runner
    from reconcile_pilot import reconcile, read, verify_integrity
    monkeypatch.setattr(pilot_orchestrator.PilotRun, '__init__', forbidden)
    monkeypatch.setattr(sut_runner.SUTRunner, '__init__', forbidden)
    monkeypatch.setattr(execution_guard, 'run_test', forbidden)
    monkeypatch.setattr(socket.socket, 'connect', forbidden)
    before = verify_integrity(ROOT, SOURCE, SNAPSHOT)
    output = tmp_path / 'result'
    report = reconcile(ROOT, SOURCE, output, SNAPSHOT)
    assert report['pilot_complete'] is True
    assert report['generated_slots'] == report['evaluated_slots'] == report['model_attempts'] == 24
    assert report['arms']['C']['resolved_requirements'] == report['arms']['I']['resolved_requirements'] == 12
    assert report['arms']['C']['mutation_score_percent'] == 76
    assert report['arms']['I']['mutation_score_percent'] == 72
    assert report['paired_difference_pp'] == -4
    assert report['budget_exposure_usd'] == read(SOURCE / 'report.json')['budget_exposure_usd']
    assert report['off_peak_usage_derived_usd'] == read(SOURCE / 'report.json')['off_peak_usage_derived_usd']
    assert report['unknown_charge_attempts'] == report['unresolved_slots'] == []
    provenance = read(output / 'provenance.json')
    assert len(provenance['amended_slots']) == 1
    assert len(provenance['unchanged_scored_slot_ids']) == 23
    assert provenance['new_runtime_smoke_verified'] is False
    assert verify_integrity(ROOT, SOURCE, SNAPSHOT) == before
    with (SOURCE / 'slots.csv').open(newline='') as stream:
        original = {r['slot_id']: r for r in csv.DictReader(stream)}
    with (output / 'slots.csv').open(newline='') as stream:
        derived = {r['slot_id']: r for r in csv.DictReader(stream)}
    for slot_id in provenance['unchanged_scored_slot_ids']:
        assert original[slot_id] == derived[slot_id]
    decision = read(output / 'amendments.json')['decisions'][0]
    assert decision['historical_classification'] == 'unclassified_failure'
    assert decision['new_classification'] == 'original_quality_failure'
    with pytest.raises(GuardError, match='already exists'):
        reconcile(ROOT, SOURCE, output, SNAPSHOT)


@pytest.mark.parametrize('target', ['ledger', 'run', 'protected', 'snapshot'])
def test_integrity_guard_rejects_changed_inputs(monkeypatch, target):
    import reconcile_pilot as module
    manifest = module.read(SNAPSHOT / 'snapshot-manifest.json')
    paths = {'ledger': HERE / 'study-budget.json', 'run': SOURCE / 'run.json',
             'protected': ROOT / 'experiments/prompts/C.txt',
             'snapshot': SNAPSHOT / next(iter(manifest['entries'].values()))['snapshot_relative']}
    selected = paths[target].resolve()
    monkeypatch.setattr(module, 'sha256', lambda p: 'changed' if Path(p).resolve() == selected else sha256(p))
    with pytest.raises(GuardError):
        module.verify_integrity(ROOT, SOURCE, SNAPSHOT)


def test_missing_ledger_never_initializes_a_file(tmp_path):
    from reconcile_pilot import ReadOnlyLedger
    path = tmp_path / 'missing.json'
    with pytest.raises(GuardError, match='Existing ledger'):
        ReadOnlyLedger(path)
    assert not path.exists()


def test_output_inside_source_is_rejected():
    from reconcile_pilot import reconcile
    with pytest.raises(GuardError, match='separate'):
        reconcile(ROOT, SOURCE, SOURCE / 'forbidden', SNAPSHOT)


def test_report_adapter_rejects_wrong_slot_identity(tmp_path):
    from pilot_report import write_report
    from test_pilot_orchestrator import make_run
    run = make_run(tmp_path)
    with pytest.raises(ValueError, match='unknown slot'):
        write_report(run, output=tmp_path / 'derived', amendments={'unknown': {}})
    with pytest.raises(ValueError, match='identity mismatch'):
        write_report(run, output=tmp_path / 'derived',
                     amendments={run.slots[0]['slot_id']: {'slot_id': 'other'}})
