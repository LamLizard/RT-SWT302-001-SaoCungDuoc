"""Reconcile the entire fixed pilot panel, including failures and missing outputs."""
import csv
from decimal import Decimal
import json
from pathlib import Path

from pilot_core import save_json
from pilot_orchestrator import stamp


def write_report(run, *, output=None, amendments=None):
    """Read the run unchanged; optionally write a derived report with declared amendments."""
    destination = Path(output) if output is not None else run.output
    destination.mkdir(parents=True, exist_ok=True)
    amendments = amendments or {}
    ids = {s['slot_id'] for s in run.slots}
    if amendments.keys() - ids:
        raise ValueError('Amendment has an unknown slot ID')
    generations = {r['slot_id']: r for r in run.generation_records()}
    evaluations, rows, contexts = {}, [], []
    for slot in run.slots:
        path = run.slot_directory(slot) / 'evaluation/evaluation.json'
        if path.exists():
            evaluations[slot['slot_id']] = json.loads(path.read_text(encoding='utf-8'))
        if slot['slot_id'] in amendments:
            amendment = amendments[slot['slot_id']]
            if amendment.get('slot_id') != slot['slot_id']:
                raise ValueError('Amendment slot identity mismatch')
            evaluations[slot['slot_id']] = amendment
        generation, evaluation = generations.get(slot['slot_id'], {}), evaluations.get(slot['slot_id'], {})
        score = evaluation.get('score')
        rows.append({'slot_id': slot['slot_id'], 'service': slot['service'], 'requirement_id': slot['requirement_id'],
                     'arm': slot['arm'], 'generation_status': generation.get('status', 'pending'),
                     'evaluation_status': evaluation.get('status', 'pending'), 'mutants': int(slot['num_mutants']),
                     'score': score['score'] if score is not None else None,
                     'passes_on_valid': score.get('passes_on_valid') if score is not None else None,
                     'reference_input_tokens': generation.get('reference_input_tokens'),
                     'provider_input_tokens': generation.get('provider_input_tokens'),
                     'completion_tokens': (generation.get('usage') or {}).get('completion_tokens'),
                     'accounted_upper_usd': (generation.get('cost') or {}).get('accounted_upper_usd'),
                     'off_peak_usage_usd': (generation.get('cost') or {}).get('off_peak_usage_usd')})
        records = {r['context']: r for r in evaluation.get('records', [])}
        for context in ['valid'] + [f'mutated_{i}' for i in range(int(slot['num_mutants']))]:
            record = records.get(context, {})
            fallback = ('not_run_generation_failed' if evaluation.get('generation_failure') else
                        'not_run_original_failed' if context != 'valid' and score is not None
                        and not score.get('passes_on_valid') else 'pending')
            metrics = record.get('instrumentation') or {}
            contexts.append({'key': slot['slot_id'] + '/' + context, 'context': context,
                             'classification': record.get('classification', fallback),
                             'pytest_executed': record.get('stage') == 'completed',
                             'http_requests': metrics.get('http_requests'),
                             'python_assertions': metrics.get('assertion_count'),
                             'distinct_http_inputs': metrics.get('distinct_http_inputs'),
                             'elapsed_seconds': record.get('elapsed_seconds'),
                             'evidence': record.get('evidence')})
    arms = {}
    for arm in ('C', 'I'):
        selected = [r for r in rows if r['arm'] == arm]
        resolved = [r for r in selected if r['score'] is not None]
        denominator = sum(r['mutants'] for r in selected)
        kills = sum(r['score'] for r in resolved)
        arms[arm] = {'requirements': len(selected), 'resolved_requirements': len(resolved),
                     'mutant_denominator': denominator, 'resolved_kills': kills,
                     'mutation_score_percent': 100 * kills / denominator if len(resolved) == len(selected) else None}
    ids = {s['slot_id'] for s in run.slots}
    attempts = {key: value for key, value in run.ledger.state['attempts'].items()
                if key.rsplit('/', 1)[0] in ids}
    unknown = [key for key, value in attempts.items() if value['status'] in {'pending', 'unknown'}]
    cleanup_files = list((run.output / 'services').glob('*/cleanup-summary.json'))
    cleanups = [json.loads(p.read_text(encoding='utf-8')) for p in cleanup_files]
    started = list((run.output / 'services').glob('*/started-stack.json'))
    cleanup_services = {c['service'] for c in cleanups}
    cleanup_verified = {p.parent.name for p in started} <= cleanup_services and all(c['cleanup_passed'] for c in cleanups)
    costs = [json.loads(p.read_text(encoding='utf-8'))
             for p in (run.output / 'slots').glob('*/attempt_*/accounting.json')]
    complete_scores = all(arms[a]['mutation_score_percent'] is not None for a in arms)
    report = {'updated_at_utc': stamp(), 'target_slots': 24, 'generated_slots': len(generations),
              'evaluated_slots': len(evaluations), 'missing_generation_slots': sorted(ids - generations.keys()),
              'missing_evaluation_slots': sorted(ids - evaluations.keys()),
              'unresolved_slots': [r['slot_id'] for r in rows if r['score'] is None], 'arms': arms,
              'paired_difference_pp': arms['I']['mutation_score_percent'] - arms['C']['mutation_score_percent']
                                      if complete_scores else None,
              'model_attempts': sum(a['status'] not in {'reserved', 'released'} for a in attempts.values()),
              'budget_limit_usd': run.ledger.state['limit'], 'budget_exposure_usd': str(run.ledger.exposure),
              'unknown_charge_attempts': unknown, 'sut_cleanup_verified': cleanup_verified,
              'provider_invoice_confirmed': False,
              'off_peak_usage_derived_usd': str(sum((Decimal(c['off_peak_usage_usd']) for c in costs), Decimal(0))),
              'accounted_attempts': len(costs),
              'pilot_complete': len(generations) == 24 and complete_scores and cleanup_verified and not unknown,
              'semantic_input_case_count': None,
              'metrics_note': 'Counts Python assert statements and distinct HTTP input signatures; semantic EP/BVA case counts require annotation.'}
    save_json(destination / 'report.json', report)
    for name, records in [('slots.csv', rows), ('executions.csv', contexts)]:
        with (destination / name).open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(records[0]))
            writer.writeheader()
            writer.writerows(records)
    text = ['# Pilot C/I report', '', f'Complete: {report["pilot_complete"]}',
            f'Generated: {len(generations)}/24; evaluated: {len(evaluations)}/24',
            f'Model attempts: {report["model_attempts"]}; budget exposure upper bound: USD {report["budget_exposure_usd"]}',
            f'Unknown charge attempts: {len(unknown)}; SUT cleanup verified: {cleanup_verified}', '',
            'Usage-derived costs are estimates under the verified tariff, not a confirmed provider invoice.', '',
            '| Arm | Resolved requirements | Mutant denominator | Resolved kills | MS_phi % |',
            '|---|---:|---:|---:|---:|']
    for arm, value in arms.items():
        text.append(f'| {arm} | {value["resolved_requirements"]}/12 | {value["mutant_denominator"]} | {value["resolved_kills"]} | {value["mutation_score_percent"]} |')
    text += ['', 'Missing generation: ' + ', '.join(report['missing_generation_slots']),
             'Unresolved evaluation: ' + ', '.join(report['unresolved_slots']), '', report['metrics_note']]
    (destination / 'REPORT.md').write_text('\n'.join(text) + '\n', encoding='utf-8')
    return report
