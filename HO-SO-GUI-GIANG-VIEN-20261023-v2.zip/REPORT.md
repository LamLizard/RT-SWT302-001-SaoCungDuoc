# Pilot C/I report

Complete: True
Generated: 24/24; evaluated: 24/24
Model attempts: 24; budget exposure upper bound: USD 0.0655344
Unknown charge attempts: 0; SUT cleanup verified: True

Usage-derived costs are estimates under the verified tariff, not a confirmed provider invoice.

| Arm | Resolved requirements | Mutant denominator | Resolved kills | MS_phi % |
|---|---:|---:|---:|---:|
| C | 12/12 | 25 | 19 | 76.0 |
| I | 12/12 | 25 | 18 | 72.0 |

Missing generation: 
Unresolved evaluation: 

Counts Python assert statements and distinct HTTP input signatures; semantic EP/BVA case counts require annotation.
