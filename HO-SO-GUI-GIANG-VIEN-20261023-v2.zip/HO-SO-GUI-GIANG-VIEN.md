# Hồ sơ đề nghị giảng viên review — FA26-EXT-12 / SaoCungDuoc

Ngày lập: 23/10/2026, Asia/Saigon. Người nhận dự kiến: cô L.T.Q.Chi. Đây là hồ sơ để người dùng review và tự gửi; chưa gửi email, chưa có xác nhận chốt RQ/thiết kế của giảng viên.

## 1. Kết quả và phạm vi

Pilot đã đóng **bằng đối soát offline có công bố**: 24/24 output, 24/24 evaluation resolved; C **19/25 = 76%**, I **18/25 = 72%**, I−C **−4 điểm phần trăm**. Chỉ sửa quyết định phân loại/chấm điểm cho một slot dựa trên bằng chứng đã lưu, không sinh lại test, không chạy lại generated test và không gọi thêm model. Run gốc vẫn ghi unresolved; bản dẫn xuất này là amendment, không ghi đè lịch sử.

Đây là một pilot replicate trên **12 requirement / 25 mutant mỗi arm**, không phải main **106 / 228**. Một lần pilot không cho phép kết luận EP+BVA tốt/kém hơn, không ước lượng biến động giữa các lần sinh và không cho phép tuyên bố tương đương. **Main chưa chạy, chưa freeze và không được phép trong nhiệm vụ đóng pilot này.**

## 2. Đối chiếu bảy yêu cầu trong mail cô Chi

Chỉ phần đầu file mail đến “Thân, Cô Chi” được xem là yêu cầu của giảng viên; phần trao đổi phía sau không phải yêu cầu mới. Nguồn: `lam/SLR/AI cua lam response.txt` trong workspace; SHA256 `ac6fe88c334c68ed0314e67082ee4fba373a65734df0b9d37aa7c85e9a94f294`.

| Mục mail | Đã thực hiện / bằng chứng | Chưa làm hoặc cần quyết định |
|---|---|---|
| 1. RQ tạo đóng góp và Rodríguez | RQ/đóng góp §3, bảng nghiên cứu gần nhất §4; [RQ đầy đủ](appendix/rq-validation.md) | Cô review tính mới và phạm vi; không nhận kỹ thuật EP+BVA/prompt là mới |
| 2. Phiên bản, dữ liệu, golden | Commit, 106/228, danh sách ID/mutant [manifest](appendix/benchmark-manifest.json); golden §5 và release | 1 mutant compile lỗi; chưa xác nhận mọi mutant runtime-valid |
| 3. Chỉ khác can thiệp C/I; ngân sách | Hai prompt đầy đủ, cùng cấu hình và cap §6; actual request/assertion §8 | Không kiểm soát số request thực dùng bằng nhau; không tách tác động riêng của EP, BVA và từng câu chỉ dẫn |
| 4. Không rò rỉ precise/reference | Renderer chỉ lấy vague + OAS + base URL; C là tiền tố của I; hashes/fixture ở phụ lục | Gate ngăn rò rỉ phải tiếp tục được giữ khi freeze/main; không dùng điểm pilot để tune prompt |
| 5. Điều chỉnh RQ và giải thích | Một RQ chính; codebook dữ liệu/biên/tiền điều kiện/oracle/thiếu hành vi ở thiết kế §9 | Chưa có hai người chấm, annotation độc lập, IAA hoặc hòa giải; không suy cơ chế từ vài ví dụ |
| 6. Kế hoạch đo lường và độ bất định | Kết quả requirement/service/arm, pass-original, request/assertion/token/chi phí §8; mẫu số giữ nguyên | Case EP/BVA ngữ nghĩa, độ đúng oracle/ràng buộc/bỏ sót chưa đo; R=3 và uncertainty cần chốt trước main |
| 7. Hồ sơ review và bước tiếp | Bộ prompt/manifest/config/lịch/golden/pilot/provenance + email nháp đã xuất | Người dùng tự review/gửi; cô chưa phê duyệt, chưa freeze/main |

## 3. RQ, PICO và đóng góp dự kiến

**RQ chính:** Trong điều kiện sinh single-step với cùng mô hình, cấu hình và ngân sách kiểm thử được quy định trước, việc bổ sung hướng dẫn EP+BVA vào prompt gốc ảnh hưởng như thế nào đến MS_φ trên các yêu cầu vague của RESTestBench tại phiên bản đóng băng?

P: 106 vague requirement ở commit khóa; I: toàn bộ C bổ sung hướng dẫn EP+BVA có căn cứ; C: prompt single-step nguyên gốc; O: MS_φ. Mục tiêu phân tích bổ trợ là mô tả input, tiền điều kiện và oracle đi kèm tăng/giảm/không đổi điểm, không tạo RQ thứ hai hay chứng minh quan hệ nhân quả.

Đại lượng Δ là chênh lệch kỳ vọng I−C qua các lần sinh trên panel cố định. H0: Δ=0; H1: Δ≠0, hai phía. Giá trị −4 điểm phần trăm trong pilot là chênh lệch quan sát của một run, không phải ước lượng confirmatory về mọi REST API/LLM.

Định vị: mở rộng thực nghiệm single-step RESTestBench bằng so sánh C/I được kiểm soát, phân tích thành công/thất bại có kiểm tra độc lập và gói tái lập. Không tuyên bố phát minh EP/BVA hoặc đưa EP/BVA vào prompt. Việc chưa thấy đủ tổ hợp P/I/C/O không tự chứng minh gap mạnh. Corpus lịch sử vẫn 42 INCLUDE + 18 nguồn nền; không đổi PRISMA hoặc tái chấm tài liệu trong lượt này.

## 4. Nghiên cứu gần nhất

Bảng dưới được chuyển từ hồ sơ đã đọc/review ngày 22/10; đây không phải lượt tìm kiếm web hoặc rà lại PDF mới. Locator phục vụ truy vết; nội dung suy luận về khoảng trống được giới hạn trong các nguồn đã đối chiếu.

| Nghiên cứu | Đầu vào / phép so thực sự | Đã cung cấp gì? | Điều chưa trả lời trực tiếp cho RQ này | Locator |
|---|---|---|---|---|
| GV-02 · RESTestBench (2026) | NL precise/vague + OAS; single-step so với refinement | Benchmark và MS_φ; đánh giá ảnh hưởng độ chi tiết và tương tác SUT | Không có phép so C với C + hướng dẫn EP+BVA | [PDF 44](../../../Paper-source/44-GV-02-RESTestBench.pdf), §3.2–4.2/PDF4–8; §5–6/PDF9 |
| **GV-18 · Rodríguez et al. (2025)** | Đặc tả + mã Java; GPT-4-0613 có hướng dẫn EP+BVA so với test thủ công; 10 scenario | EP+BVA trong prompt đã tồn tại; 30 lớp test LLM/10 lớp thủ công; đánh giá PIT, coverage và định tính | Không có đối chứng LLM bỏ hướng dẫn EP+BVA; không thực nghiệm vague REST API/MS_φ | [PDF 60](../../../Paper-source/60-Martin%20Rodriguez.pdf), §3/PDF4–8; Tables1–2/PDF9–10; §5–6/PDF10–13; [arXiv](https://arxiv.org/abs/2505.09830) |
| TD-0002 · RestTSLLM (2025) | OpenAPI → TSL → integration tests; so các LLM trên 6 dự án .NET | Có equivalence/boundary trong hướng dẫn; đo mutation bằng Stryker.NET | Không phải baseline single-step của RESTestBench; mutation score không tự là MS_φ | [PDF 39](../../../Paper-source/39-TD-0002.pdf), §3/PDF3–4; §4.3–4.6/PDF6–8; Table3/PDF8 |
| GV-03 · Prompt-Based REST API Test Amplification in Industry (2026) | Test có sẵn + ngữ cảnh; amplification cho 6 endpoint công nghiệp | Bằng chứng replication công nghiệp, coverage và công sửa test | Không so hai prompt trên vague RESTestBench; coverage không thay MS_φ | [PDF 45](../../../Paper-source/45-GV-03-Prompt-Based-REST-API-Amplification.pdf), §4–5/PDF3–6; §7/PDF7 |
| GV-04 · RESTOR (2026) | Một request–response quan sát được; oracle generation với GRPO | Đánh giá chất lượng oracle trong REST API | Không phải sinh test single-step chỉ từ vague + OAS, không đối chứng EP+BVA/MS_φ | [PDF 46](../../../Paper-source/46-GV-04-RESTOR.pdf), §3–5; §7/PDF18–19 |

Riêng Rodríguez et al. (2025) đã dùng EP+BVA trong prompt; đối chứng của họ là test thủ công trong bối cảnh unit test Java có mã nguồn, không phải LLM single-step bỏ EP+BVA trên vague REST API. Đây là căn cứ phân biệt phép so, không phải bằng chứng khẳng định không có nghiên cứu tương tự ở toàn lĩnh vực. Nguồn cô nêu: [bản arXiv](https://arxiv.org/abs/2505.09830); locator đầy đủ trong RQ appendix, chưa kiểm web lại ở lượt đóng pilot.

## 5. Benchmark và golden lịch sử

RESTestBench commit `4decc1e36ea3dd41b64ce3e3ac6a85bc72df36ae`: FastAPI **63 requirement/141 mutant**, NestJS RealWorld **29/65**, TodoApp **14/22**, tổng **106/228**. README cùng commit ghi 26 RealWorld, trong khi dữ liệu thực là 29; không lấy tổng 103 của README thay manifest. [Manifest đầy đủ](appendix/benchmark-manifest.json) giữ requirement path, service, mutant index 0-based, Git blob và OAS/source provenance.

Golden full run ngày 22–23/10: **106 original pass, 227 assertion kill, 1 mutant compile error, 106 restored original pass**; 439 pytest thực chạy. FastAPI 63/141/0/63, NestJS 29/64/1/29, TodoApp 14/22/0/14 theo thứ tự original/kill/compile/restored. Đây là bằng chứng lịch sử, không chạy lại golden/Docker/build trong lượt này.

Mutant `nestjs-realworld/5/mutated_0` lỗi TS2741 vì object trả về thiếu `DeleteResult.raw`, pytest chưa chạy. Không tính kill, không ghi thành runtime-survived, không sửa/loại mutant; mẫu số main vẫn **228**. [Release ngày 23/10](appendix/step-1-release-20261023.json) xác nhận bước 1 `completed_with_known_failure`, `step_1_complete=true`, `blocks_step_2=false`, `all_mutants_runtime_validated=false`. Nhãn blocked trong [REPORT golden cũ](appendix/golden-REPORT-history.md) là lịch sử đã được release thay về workflow; kết quả runtime cũ không thay đổi.

## 6. Prompt, chống rò rỉ và ngân sách chung

Hai prompt nguyên văn: [C](appendix/prompts/C.txt), [I](appendix/prompts/I.txt). C SHA256 `af717c86e54149aef250e98fa471b0c7942144d3011e9e83786399962c1c9275`; I SHA256 `43abf1588e21b5e5c026182eeabf5f479cca57d3ff915751333c8929da49cce2`. I giữ toàn bộ C làm tiền tố, chỉ nối sáu chỉ dẫn EP+BVA có căn cứ, không ví dụ mới hoặc output format mới. Có cho phép comment ngắn về thông tin thiếu; đây cũng là một phần của gói I. Không thay prompt sau khi nhìn pilot.

Input chỉ gồm `requirement_vague`, toàn bộ OAS và base URL theo ba placeholder của baseline. Precise, golden, source/mutant và điểm không đi vào generation. [Config nguyên trạng](appendix/study-config.json) và [lịch nguyên trạng](appendix/run-schedule.csv) là baseline review ngày 22/10, có trạng thái lịch sử chưa thực thi; không phải giấy phép main hoặc trạng thái mới nhất. Trạng thái thực thi hiện hành nằm trong report/provenance của bản đối soát này.

Hai arm có cùng model/API alias `deepseek-flash` (checkpoint mong đợi Flash-1017), thinking disabled, temperature 0.2, top_p 1, max output 2.048 token, một user message, không custom system/tools, không feedback hoặc semantic repair; một response có nội dung/slot, tối đa một transport retry khi đủ điều kiện, concurrency=1. Metadata response của 24 output ghi alias `deepseek-flash`; đây không phải bằng chứng khóa weights bất biến.

Cap chung: **64 HTTP request / execution** gồm setup/cleanup và **60 giây / context**, reset SUT trước mỗi original/mutant. Một hàm pytest không có nghĩa một case hay ngân sách bằng nhau: phải báo lượng request/assertion thực dùng. Lỗi cap/timeout/instrumentation/reset/network giữ unresolved, không trở thành kill. Original fail vì chất lượng output thì k=0, không kill và giữ toàn bộ mutant của requirement trong mẫu số theo thiết kế §5 và Evaluator gốc.

Trần toàn nghiên cứu **USD3**, gồm pilot/main/retry và phí chưa biết. Ledger hiện có chặn trên **USD0.0655344**; ước tính off-peak từ usage **USD0.022192608** theo biểu giá đã lưu, **chưa phải hóa đơn**. Unknown-charge attempts: 0; model attempts: 24. Không reset ledger. Giá/model/window phải xác minh lại trước live run tương lai; lượt này không tra giá/model mới.

## 7. Amendment hậu xử lý và kiểm chứng

Run gốc: `.local/pilot-preparation/pilot-run-20261023-01`. Slot `pilot/r1/nestjs-realworld/8/C` phát sinh `KeyError` ở dòng 33 `resp.json()["article"]["slug"]`; original trả ArticleEntity trực tiếp theo source đã khóa. Test đã gửi 2 request, vượt qua 2 assertion trước lỗi đọc response, chưa đi tới kiểm tra xóa comment. JUnit/stdout, source line, mã pytest đã chạy, instrumentation, reset DB/health và khôi phục được đối chiếu. Không suy nhãn định tính oracle/unsupported chỉ từ việc này.

Classifier cũ chỉ cho `original_assertion_failure` nhận 0. Amendment bổ sung `original_quality_failure` có bằng chứng, vẫn giữ loại lỗi runtime thật và classification lịch sử. Quy tắc không phụ thuộc slot ID, arm hay tên trường response. Chỉ nhận dạng hẹp lỗi JSON lookup sau assertion 2xx; exception không rõ dữ liệu hoặc bằng chứng thiếu tiếp tục unresolved. Lỗi tương tự ở mutant không tự thành kill; cap/instrumentation được ưu tiên.

Score mới của slot do cùng classifier + Evaluator gốc tính: **k=0/2, passes_on_valid=false, mutants_killed=[]**; hai mutant ghi **không chạy vì original fail**. Không tạo result pytest/mutant chưa tồn tại. 23 slot đã scored còn lại giữ nguyên theo slot ID. Aggregate dùng lại `pilot_report.write_report` qua adapter chỉ đọc, không qua `PilotRun.__init__`, không resume/tắt identity gate.

Snapshot: 2007 file; run gốc 1601 file; 28741 file benchmark/golden/evaluator/prompts/config/lịch được bảo vệ đã kiểm hash trước/sau. [Provenance](provenance.json) nối source/run cũ, source xử lý mới và evidence hashes; [snapshot manifest](snapshot-manifest.json) định danh từng bản sao. Snapshot dùng tên file ngắn để tránh giới hạn đường dẫn Windows; bản copy lồng thư mục chưa hoàn chỉnh giữ riêng, không phải nguồn snapshot chính thức.

Regression trên đúng mã cũ và fixture cuối: **3 failed dự kiến**, xác nhận lỗi trước sửa. Kiểm tập trung: **54 passed**; sau bổ sung kiểm tra adapter SUT giả lập, bộ unit cuối: **136 passed, 0 fail/error/skip**, exit 0. [JUnit](unit-closeout.xml), [log](unit-closeout.log), [nhật ký lệnh](COMMANDS.md). Lượt full đầu trong sandbox có 135 pass/1 fail do Windows chặn socket loopback (WinError 10013); tái hiện độc lập rồi chạy lại ngoài sandbox với quyền loopback đã đạt, không sửa worker hoặc test để né lỗi. Unit dùng receipt/adapter giả lập và server loopback của test runner; không khởi động SUT thật, không gọi DeepSeek. Mọi lần thử red hoặc chạy chẩn đoán thêm được giữ trong nhật ký, không tính là output pilot.

Smoke/preflight cũ xác minh source cũ (lịch sử 101 unit và 13 pytest fixture); **không chuyển thành xác minh runtime cho mã mới**. Cần smoke/preflight ràng buộc hash mã mới trước live run tương lai. Không tuyên bố đã kiểm 100% runtime hay main-ready.

## 8. Kết quả pilot đầy đủ

### 8.1. Theo dịch vụ

| Dịch vụ | Arm | Resolved | Pass original | Kill / mẫu số | MS_φ (%) |
|---|---|---|---|---|---|
| fastapi | C | 4/4 | 4/4 | 7/9 | 77.78 |
| nestjs-realworld | C | 4/4 | 2/4 | 6/10 | 60.00 |
| todoapp | C | 4/4 | 4/4 | 6/6 | 100.00 |
| fastapi | I | 4/4 | 4/4 | 7/9 | 77.78 |
| nestjs-realworld | I | 4/4 | 2/4 | 5/10 | 50.00 |
| todoapp | I | 4/4 | 4/4 | 6/6 | 100.00 |

### 8.2. Theo requirement, giữ mọi test fail original

| Dịch vụ | Requirement | Mutant | C kill | I kill | I−C kill | Original C / I | Request C / I | Assert C / I |
|---|---|---|---|---|---|---|---|---|
| fastapi | 12 | 3 | 3 | 3 | 0 | valid_pass / valid_pass | 2 / 2 | 13 / 14 |
| fastapi | 26 | 2 | 1 | 1 | 0 | valid_pass / valid_pass | 4 / 5 | 19 / 14 |
| fastapi | 43 | 3 | 2 | 2 | 0 | valid_pass / valid_pass | 5 / 5 | 16 / 16 |
| fastapi | 47 | 1 | 1 | 1 | 0 | valid_pass / valid_pass | 1 / 1 | 6 / 6 |
| nestjs-realworld | 4 | 3 | 3 | 0 | -3 | valid_pass / original_assertion_failure | 4 / 3 | 17 / 19 |
| nestjs-realworld | 8 | 2 | 0 | 2 | 2 | original_quality_failure / valid_pass | 2 / 6 | 2 / 10 |
| nestjs-realworld | 19 | 2 | 0 | 0 | 0 | original_assertion_failure / original_assertion_failure | 5 / 4 | 14 / 13 |
| nestjs-realworld | 22 | 3 | 3 | 3 | 0 | valid_pass / valid_pass | 3 / 3 | 16 / 20 |
| todoapp | 5 | 1 | 1 | 1 | 0 | valid_pass / valid_pass | 13 / 11 | 31 / 27 |
| todoapp | 8 | 2 | 2 | 2 | 0 | valid_pass / valid_pass | 10 / 8 | 17 / 19 |
| todoapp | 11 | 1 | 1 | 1 | 0 | valid_pass / valid_pass | 3 / 3 | 6 / 4 |
| todoapp | 12 | 2 | 2 | 2 | 0 | valid_pass / valid_pass | 7 / 7 | 20 / 19 |

Các cột request/assertion là số thực thi trên **original**, gồm phần đã chạy trước khi test fail. `original_quality_failure` là amendment; `original_assertion_failure` là lỗi assertion đã được ghi từ trước. Tỷ lệ theo từng requirement là kill chia số mutant tương ứng; [CSV requirement](requirements.csv), [CSV slot](slots.csv), [CSV mọi context](executions.csv) giữ định danh và evidence. Không dùng trung bình không trọng số của các tỷ lệ requirement để thay MS_φ.

### 8.3. Khả năng dùng output, ngân sách thực dùng và thời gian

| Chỉ số | C | I |
|---|---|---|
| Output / cú pháp hợp lệ / đúng một hàm test | 12 / 12 / 12 | 12 / 12 / 12 |
| Đã thực thi pytest trên original | 12/12 | 12/12 |
| Pass original | 10/12 (83.33%) | 10/12 (83.33%) |
| Fail original / unresolved | 2 / 0 | 2 / 0 |
| HTTP request trên original (kể cả test fail một phần) | 59 | 58 |
| Python assert thực thi trên original | 177 | 181 |
| Tổng chữ ký HTTP phân biệt trong từng original context | 51 | 53 |
| Pytest context mutant thực chạy | 21 | 20 |
| Tổng pytest original + mutant | 33 | 32 |
| HTTP request / assert trên mọi context đã chạy | 139 / 410 | 137 / 409 |
| Provider input token / completion token | 73762 / 8868 | 76738 / 8119 |
| Provider cache-hit input token | 35584 | 36352 |
| Tổng thời gian transport ghi trong receipt (giây) | 45.596 | 42.937 |
| Transport min / median / max (giây) | 2.657 / 3.750 / 5.063 | 2.297 / 3.609 / 4.125 |
| Tổng elapsed pytest process (giây) | 43.343 | 40.582 |
| Chặn trên hạch toán USD | 0.0327702 | 0.0327642 |
| Ước tính off-peak theo usage USD | 0.011154252 | 0.011038356 |

Có 24/24 output parse được cú pháp và đúng một test function; 24/24 đã được pytest thực thi trên original; **20/24 pass original**. Cả C và I đều 10/12 pass, 2/12 fail, 0 unresolved sau đối soát. “Cú pháp hợp lệ”, “đã thực thi”, “pass original” và “resolved” là các khái niệm khác nhau. Không dùng nhãn output chạy được để ngụ ý đã đúng hành vi hoàn toàn.

Số chữ ký HTTP là tổng distinct method/URL/body trong từng context, không phải global unique hoặc số case EP/BVA. Python assert và HTTP request không đồng nhất case ngữ nghĩa. **Số case EP/BVA, tỷ lệ oracle đúng/sai/unsupported, bỏ sót hành vi, IAA: chưa đo/chưa annotation.** Pass-original một mình không chứng minh oracle đúng hoàn toàn. Thời gian ở bảng là số từ transport receipt/pytest process, chưa đo tổng wall-clock chuẩn hóa hoặc thời gian reset/build; không cộng thành thời gian toàn nghiên cứu.

Một run không hỗ trợ SD/range giữa lần sinh hoặc CI về ngẫu nhiên generation. R=3/636 main slot vẫn là phương án nguồn lực chưa chốt (`main_runs_finalized=false`), không phải power analysis. Kế hoạch ghép theo requirement/run, giữ cụm mutant, raw Δ_r, độ lớn và giới hạn bất định ở thiết kế §8; không dùng 228 mutant như quan sát độc lập và không chọn run tốt nhất.

## 9. Tồn đọng và người cần quyết định

| Mã | Quyết định / dữ liệu còn thiếu | Ai cần xử lý | Ảnh hưởng main / bước tiếp theo |
|---|---|---|---|
| P1 | Hai người chấm độc lập, giờ công, deadline, người hòa giải | Nhóm nghiên cứu | Chưa đáp ứng gate định tính; Chốt danh tính, phân công, lịch và quy tắc hòa giải; giữ nhãn ban đầu |
| P2 | Annotation EP/BVA, oracle, ràng buộc và bỏ sót | Hai người chấm do nhóm chỉ định | Cần đánh dấu cơ hội từ vague + OAS theo codebook trước main, không đọc mutant để chọn case; Áp dụng codebook §9, công bố dữ liệu pilot đã được nhìn thấy; không giả vờ annotation pilot là mù trước output |
| P3 | Căn cứ chọn R và phân tích độ bất định | Nhóm nghiên cứu, xin giảng viên review | main_runs_finalized=false; chưa freeze; Bảo vệ lựa chọn R/precision trong trần USD3 và phương pháp ghép cụm trước main; không chọn theo dấu điểm pilot |
| P4 | Giảng viên xác nhận RQ/đóng góp/thiết kế | Người dùng gửi; cô Chi review | Chưa được xác nhận chốt thiết kế; Người dùng review bộ hồ sơ và tự gửi email nháp |
| P5 | Freeze, model mapping, giá, token/charge, preflight và smoke của mã mới | Nhóm vận hành và người dùng phê duyệt main | Cần xác minh lại theo thời gian và hash nguồn mới; main không được phép ở nhiệm vụ này; Sau quyết định nghiên cứu, khóa hash/amendment và revalidate trước live run; không resume identity run cũ |
| P6 | Lỗi compile NestJS 5/mutated_0 | Nhóm nghiên cứu, giảng viên review giới hạn | Chưa thể tuyên bố 228 mutant runtime-valid hoặc benchmark hoàn chỉnh nếu context này vẫn unresolved; Giữ mẫu số 228 và không kill; nếu cần đổi benchmark/protocol phải có quyết định riêng trước main |
| P7 | Hóa đơn phí provider | Người dùng/nhóm có quyền đối soát billing | Cần tiếp tục admission/accounting trong trần USD3; Đối chiếu phí thực khi có; không tự nhận ước tính là hóa đơn hoặc khởi tạo lại ledger |

Các mục này **không ngăn gửi hồ sơ review có công bố giới hạn**, nhưng chưa thể coi nghiên cứu hoàn thành hoặc sẵn sàng main. Hai người chấm/giờ công/deadline, annotation/hòa giải, căn cứ R/uncertainty, xác nhận cô, freeze và revalidation đều chưa được tự điền hoặc tự chốt. Lỗi NestJS 5/0 vẫn là giới hạn runtime riêng của toàn benchmark, không phải slot unresolved còn lại của pilot.

## 10. Phụ lục và cách review

- [Report JSON](report.json), [report tự động](REPORT.md), [metrics JSON](pilot-metrics.json), bảng requirement/service/slot/context và [pending decisions](pending-decisions.csv).
- [Provenance](provenance.json), [amendments](amendments.json), [snapshot manifest](snapshot-manifest.json), [kiểm cuối](final-checks.json), [lệnh và kết quả](COMMANDS.md).
- `appendix/`: hai prompt nguyên văn, manifest/config/lịch nguyên trạng với SHA256 trong `artifact-hashes.json`; RQ/thiết kế, release/golden và excerpt lỗi đã bỏ JWT SUT. Bản golden report cũ có nhãn blocked lịch sử; luôn đọc kèm release mới.
- [Email nháp](EMAIL-NHAP.md) để người dùng tự gửi. Gói ZIP cuối `HO-SO-GUI-GIANG-VIEN-20261023-v2.zip` kèm các tài liệu/bảng/phụ lục cần review, không kèm raw trace có token, ledger tài khoản hoặc toàn bộ snapshot cục bộ. Bản ZIP không hậu tố là draft đóng gói đầu, giữ lại để truy vết; dùng v2 khi gửi. Raw evidence/snapshot vẫn được giữ tại workspace theo manifest, nên gói gửi là hồ sơ review, chưa phải toàn bộ gói tái lập runtime.

**Trạng thái bàn giao:** hồ sơ sẵn sàng để người dùng review/gửi; pilot đã đóng qua amendment có bằng chứng; main chưa chạy/chưa được phép, giảng viên chưa chốt. Không sửa benchmark/golden/evaluator, prompt C/I, manifest/config/lịch hoặc generated test; không cài dependency, commit/push hay liên hệ giảng viên.
