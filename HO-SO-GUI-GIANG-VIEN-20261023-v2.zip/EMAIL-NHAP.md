# Email nháp — người dùng tự review và gửi

**Tiêu đề:** [SWT302 – SaoCungDuoc] Hồ sơ RQ/thiết kế và kết quả pilot RESTestBench để cô review

Kính gửi cô Chi,

Nhóm SaoCungDuoc gửi cô hồ sơ cập nhật gồm RQ và đóng góp dự kiến, bảng đối chiếu nghiên cứu gần nhất (đặc biệt Rodríguez et al.), commit/thống kê RESTestBench, hai prompt đầy đủ, ngân sách kiểm thử và kết quả golden/pilot.

Benchmark đã kiểm kê 106 yêu cầu/228 mutant tại commit 4decc1e36ea3dd41b64ce3e3ac6a85bc72df36ae. Golden ghi nhận một mutant NestJS 5/0 không biên dịch; nhóm giữ mẫu số 228 và không tính lỗi này là kill.

Pilot một lần trên 12 yêu cầu có 24/24 evaluation resolved sau một amendment hậu xử lý được công bố: C 19/25 (76%), I 18/25 (72%). Amendment áp dụng quy tắc original-fail đã có trong thiết kế cho lỗi đọc response ở generated test, không sửa test, sinh lại output hoặc chạy thêm model. Kết quả này chỉ xác minh pipeline; nhóm chưa kết luận EP+BVA tốt/kém hơn.

Nhóm chưa chạy main và chưa freeze. Hồ sơ nêu rõ các phần còn cần chốt: hai người chấm độc lập/giờ công/deadline và hòa giải, annotation định tính, căn cứ số lần sinh và phân tích độ bất định, cùng smoke/preflight theo mã mới trước main.

Kính nhờ cô review câu hỏi nghiên cứu, đóng góp và các điều kiện thực nghiệm còn mở để nhóm thống nhất trước khi triển khai đánh giá chính thức.

Em gửi kèm bộ hồ sơ và các phụ lục để cô thuận tiện đối chiếu.

Em cảm ơn cô.
Nhóm SaoCungDuoc

---
Đây là bản nháp; chưa có email nào được gửi và chưa có xác nhận phê duyệt của cô.
