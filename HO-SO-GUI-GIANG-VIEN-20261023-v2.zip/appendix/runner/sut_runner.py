"""Run retained generated code against pinned SUT contexts; no model calls here."""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import sys

from execution_guard import audit_runner, run_test, score_requirement, review_original_failure
from pilot_core import GuardError, save_json

QUALITY_FAILURES = {'empty_output', 'truncated_output', 'invalid_syntax', 'invalid_test_count', 'unsupported_response'}


def verify_restored_tree(original, working, service, *, allow_build_cache=False):
    result = audit_runner().verify_working_sources(original, working)
    caches = [p for p in result['mismatches'] if service == 'todoapp' and p.startswith(('obj/', 'bin/'))]
    source = [p for p in result['mismatches'] if p not in caches]
    result.update(all_files_match=result['restored'], build_cache_mismatches=caches, source_mismatches=source)
    result['restored'] = result['checked_files'] > 0 and not source and (allow_build_cache or not caches)
    return result


@contextmanager
def without_provider_key():
    secret = os.environ.pop('DEEPSEEK_API_KEY', None)
    try:
        yield
    finally:
        if secret is not None:
            os.environ['DEEPSEEK_API_KEY'] = secret


class SUTRunner:
    def __init__(self, root, service, output, *, manager=None, executor=run_test, retry_execution=False):
        self.root, self.service, self.output = Path(root).resolve(), service, Path(output).resolve()
        self.benchmark = self.root / '.local/RESTestBench'
        if str(self.benchmark) not in sys.path:
            sys.path.insert(0, str(self.benchmark))
        from src.config import get_service_config
        self.config = get_service_config(service)
        self.output.mkdir(parents=True, exist_ok=True)
        session = self.output / f'session_{1 + len(list(self.output.glob("session_*")))}'
        self.manager = manager or audit_runner().make_manager(self.benchmark, service, session)
        self.executor, self.started = executor, False
        self.retry_execution = retry_execution

    def start(self):
        if self.started:
            return
        for path in [self.manager.get_original_path(self.service), self.manager.get_working_path(self.service)]:
            path = path.resolve()
            if not path.is_relative_to((self.benchmark / 'services').resolve()) or not path.is_dir():
                raise GuardError('SUT paths must be existing directories within the pinned benchmark')
        occupied = self.manager._is_port_in_use(self.config.port)
        marker = self.output / 'started-stack.json'
        previous = json.loads(marker.read_text(encoding='utf-8')) if marker.exists() else {}
        current = self._container_ids()
        if occupied or current:
            if not current or current != previous.get('owned_container_ids'):
                raise GuardError(f'Port {self.config.port} is occupied; existing services will not be stopped')
            # Same run and exact Docker IDs: recover its own interrupted stack.
            self.started = True
            with without_provider_key():
                self.manager.reset_working_copy(self.service)
                self.manager.call_reset_script(self.service, self.config.port)
            return
        with without_provider_key():
            self.manager.reset_working_copy(self.service)
            self.started = True  # also clean up a partially started stack
            save_json(marker, {'service': self.service, 'pid': os.getpid(), 'owned_container_ids': []})
            self.manager.start_service(self.service, self.config.port, max_wait_seconds=120)
            self.manager.wait_for_service_health(self.service, self.config.port)
            save_json(marker, {'service': self.service, 'pid': os.getpid(),
                               'owned_container_ids': self._container_ids()})

    def _container_ids(self):
        import subprocess
        result = subprocess.run(['docker', 'ps', '--filter', f'label=com.docker.compose.project={self.service}',
                                 '--format', '{{.ID}}'], capture_output=True, text=True, timeout=30, check=True)
        return sorted(result.stdout.split())

    def restore(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.manager.evidence = directory
        self.manager.context = 'restore'
        self.manager.reset_working_copy(self.service)
        original = self.manager.get_original_path(self.service) / self.config.source_subdir
        working = self.manager.get_working_path(self.service) / self.config.source_subdir
        copied = verify_restored_tree(original, working, self.service)
        save_json(directory / 'source-copy-verification.json', copied)
        if not copied['restored']:
            raise GuardError('SUT source copy mismatch before restart')
        self.manager.call_reset_script(self.service, self.config.port)
        result = verify_restored_tree(original, working, self.service, allow_build_cache=True)
        save_json(directory / 'post-health-verification.json', result)
        if not result['restored']:
            raise GuardError('SUT source restoration mismatch')
        result.update(reset_verified=True, healthy=True)
        save_json(directory / 'restoration.json', result)
        return result

    def run_context(self, source, requirement, context, directory, mutant_index=None):
        directory = Path(directory)
        result_path = directory / 'context-result.json'
        if result_path.exists():
            previous = json.loads(result_path.read_text(encoding='utf-8'))
            if not self.retry_execution or previous['classification'] in {
                    'valid_pass', 'original_assertion_failure', 'survived', 'killed_by_assertion'}:
                return previous
            save_json(directory / f'context-history-{1 + len(list(directory.glob("context-history-*.json")))}.json', previous)
        directory.mkdir(parents=True, exist_ok=True)
        attempt = directory / f'attempt_{1 + len(list(directory.glob("attempt_*")))}'
        attempt.mkdir()
        self.manager.evidence = attempt / 'preparation'
        self.manager.evidence.mkdir()
        self.manager.context = context
        result = {'context': context, 'classification': 'infrastructure_or_execution_error',
                  'counted_as_kill': False, 'stage': 'reset_source', 'evidence': str(attempt)}
        try:
            self.manager.reset_working_copy(self.service)
            if mutant_index is not None:
                result['stage'] = 'patch'
                self.manager.apply_mutation(self.service, requirement.mutants[mutant_index])
            result['stage'] = 'reset_database_health'
            self.manager.call_reset_script(self.service, self.config.port)
            result['stage'] = 'pytest'
            result.update(self.executor(source, attempt / 'pytest', context=context, request_cap=64, elapsed_cap=60,
                                        allowed_origin=f'http://localhost:{self.config.port}'))
            result['stage'] = 'completed'
        except Exception as exc:
            result['error'] = f'{type(exc).__name__}: {exc}'
        save_json(result_path, result)
        return result

    def evaluate(self, generation, entry, directory):
        directory = Path(directory)
        result_path = directory / 'evaluation.json'
        if result_path.exists():
            previous = json.loads(result_path.read_text(encoding='utf-8'))
            if not self.retry_execution or previous.get('status') != 'unresolved':
                return previous
            save_json(directory / f'evaluation-history-{1 + len(list(directory.glob("evaluation-history-*.json")))}.json', previous)
        directory.mkdir(parents=True, exist_ok=True)
        count = entry['num_mutants']
        base = {'slot_id': generation['slot_id'], 'service': self.service,
                'requirement_id': entry['requirement_id'], 'arm': generation['arm'],
                'mutant_denominator': count, 'records': [], 'score': None, 'status': 'unresolved'}
        if generation['status'] in QUALITY_FAILURES:
            base.update(status='scored_generation_failure', generation_failure=generation['status'],
                        score={'score': 0, 'passes_on_valid': False, 'mutants_killed': [],
                               'mutants_survived': list(range(count))},
                        not_run_generation_failed=['valid'] + [f'mutated_{i}' for i in entry['mutant_indices']])
            save_json(result_path, base)
            return base
        if generation['status'] != 'ready':
            base['reason'] = generation['status']
            save_json(result_path, base)
            return base
        from src.mutator import Requirement
        requirement = Requirement.from_file(self.benchmark / entry['path'])
        self.manager.requirement = requirement
        source = Path(generation['code_path']).read_text(encoding='utf-8')
        with without_provider_key():
            try:
                valid = self.run_context(source, requirement, 'valid', directory / 'valid')
                base['records'].append(valid)
                if valid['classification'] == 'valid_pass':
                    for index in entry['mutant_indices']:
                        base['records'].append(self.run_context(source, requirement, f'mutated_{index}',
                                                                 directory / f'mutated_{index}', index))
                scored = score_requirement(base['records'], self.benchmark,
                                           requirement_id=entry['requirement_id'], num_mutants=count)
                base.update(scored)
            finally:
                restore_dir = directory / f'restore_{1 + len(list(directory.glob("restore_*")))}'
                try:
                    base['restoration'] = self.restore(restore_dir)
                except Exception as exc:
                    base.update(status='unresolved', score=None, restoration_error=f'{type(exc).__name__}: {exc}')
                else:
                    if base['records'] and base['records'][0].get('evidence'):
                        valid = base['records'][0]
                        evidence = Path(valid['evidence'])
                        amended = review_original_failure(
                            valid, generated_test=generation['code_path'], execution_directory=evidence / 'pytest',
                            preparation_directory=evidence / 'preparation', restoration=base['restoration'],
                            service=self.service)
                        if amended != valid:
                            base['records'][0] = amended
                            base.update(score_requirement(base['records'], self.benchmark,
                                        requirement_id=entry['requirement_id'], num_mutants=count))
                save_json(result_path, base)
        return base

    def close(self):
        if not self.started:
            return {'service': self.service, 'cleanup_passed': True, 'started_by_this_run': False}
        cleanup = self.output / f'cleanup_{1 + len(list(self.output.glob("cleanup_*")))}'
        cleanup.mkdir()
        result = {'service': self.service, 'cleanup_passed': False, 'started_by_this_run': True}
        with without_provider_key():
            try:
                result['restoration'] = self.restore(cleanup / 'restore')
            except Exception as exc:
                result['restoration_error'] = f'{type(exc).__name__}: {exc}'
            try:
                self.manager.evidence = cleanup
                self.manager._run_script(self.service, 'stop.sh', timeout=60)
                command = self.manager.checked_command(
                    ['docker', 'ps', '--filter', f'label=com.docker.compose.project={self.service}',
                     '--format', '{{.Names}}'], 'running-containers')
                if command['stdout'].strip():
                    raise GuardError('Owned containers are still running after stop')
                # .NET recreates obj/bin during startup. Restore all files again
                # after shutdown, then require exact hashes including build cache.
                self.manager.reset_working_copy(self.service)
                original = self.manager.get_original_path(self.service) / self.config.source_subdir
                working = self.manager.get_working_path(self.service) / self.config.source_subdir
                result['final_source_verification'] = verify_restored_tree(original, working, self.service)
                result['cleanup_passed'] = 'restoration' in result and result['final_source_verification']['restored']
            except Exception as exc:
                result['stop_error'] = f'{type(exc).__name__}: {exc}'
        save_json(cleanup / 'cleanup.json', result)
        self.started = False
        return result
